import argparse

from pyspark.sql import SparkSession

from plutus.code.pipeline.spark_ohlcv import get_ohlcv


if __name__ == "__main__":
    """Main pipeline script.

    The intention is that this will create the spark session and call each
    step of the pipeline as well as pass the dataframes around.
    """

    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--strategy', help="Strategy name")
    parser.add_argument(
        '--s3_results_uri', help="S3 Bucket URL/path for results")
    parser.add_argument(
        '--database_url', help="Stocks mongodb url")
    parser.add_argument(
        '--eod_token', help="EOD API token")
    parser.add_argument(
        '--marketstack_token', help="Marketstack API token")
    args = parser.parse_args()

    # Create one spark session and reuse it among all steps.  It seems to
    # break things if one creates a new session within each function.
    with SparkSession.builder.appName('Plutus').getOrCreate() as spark:        
        print("initialized spark session")

        print("Starting ohlcv tester")
        training_df, backtesting_df = get_ohlcv(
            spark=spark,
            strategy=args.strategy,
            s3_results_uri=args.s3_results_uri,
            database_url=args.database_url,
            marketstack_token=args.marketstack_token,
            eod_token=args.eod_token,
        )
