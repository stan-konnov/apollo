#!/usr/bin/env bash
set -x

source .venv/bin/activate
cd plutus/commands
python3 produce_training_output.py $STRATEGY
aws s3 cp ../outputs/${STRATEGY}.csv s3://${ML_S3_BUCKET}/training/
aws s3 cp ../outputs/${STRATEGY}-backtesting.csv s3://${ML_S3_BUCKET}/backtesting/


