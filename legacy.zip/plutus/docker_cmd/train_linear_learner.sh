#!/usr/bin/env bash
set -x

source .venv/bin/activate
cd plutus/commands
python3 train_linear_learner.py --input $DATA_CSV