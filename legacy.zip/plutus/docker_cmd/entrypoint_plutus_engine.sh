#!/usr/bin/env bash
set -x

source .venv/bin/activate
cd plutus/rtp
python3 -u main.py