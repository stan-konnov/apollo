#!/usr/bin/env bash
set -x

source .venv/bin/activate
cd plutus/commands
python3 calculate_indicators.py