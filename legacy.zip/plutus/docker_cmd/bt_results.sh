#!/usr/bin/env bash
set -x

source .venv/bin/activate
cd plutus/commands
python3 bt_results.py --strategy $STRATEGY