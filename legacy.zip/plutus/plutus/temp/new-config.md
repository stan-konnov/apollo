This is an example of how JSON config will change according to new way we implement strategies

{
  "strategy_file": "custom_long",

  "strategy_name": "CustomLongStrategy",

  "tickers": {

    "CRM": {

      "start_date": "2022-05-01-00:00",

      "end_date": "2023-05-01-00:00"
    }
  },

  "backtesting": {

    "CRM": {

      "start_date": "2022-05-01-00:00",

      "end_date": "2023-05-01-00:00"
    }
  }
}