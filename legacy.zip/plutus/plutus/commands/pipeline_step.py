import argparse
import os
from plutus.code.pipeline.ohlcv import get_ohlcv
from plutus.code.pipeline.backtesting_v1 import backtesting_transform
from plutus.code.pipeline.backtesting_v2 import backtesting_v2
from plutus.code.pipeline.calc_indicator_manager import calc_indicator_manager
from plutus.code.pipeline.prep_training_data import prep_training_data
from plutus.code.pipeline.train_linear_learner import train_linear_learner
from plutus.code.utils.read_config import read_config_file

if __name__ == '__main__':

    # Command line arguments
    arg_parser = argparse.ArgumentParser(
        prog=os.path.basename(__file__),
        description='Trains a model'
    )
    arg_parser.add_argument(
        "--strategy",
        help="Name of the csv file to use for training, including file extension",
        required=True
    )
    args = arg_parser.parse_args()

    strategy_config = read_config_file(args.strategy)

    # This script is run as one sagemaker pipeline step
    # with multiple sub-steps (to avoid the overhead of
    # kicking off multiple sagemaker processing jobs)

    # 1. fetch OHLCV values and compile initial CSV
    get_ohlcv(strategy=strategy_config, strategy_name=args.strategy)

    # 2. Calculate indicators
    calc_indicator_manager(strategy=args.strategy)

    # 3. Reduce indicator outputs and convert data for training algo
    prep_training_data(strategy=args.strategy)

    # 4. Run training
    train_linear_learner(strategy=args.strategy)

    # 5. Run backtesting transform to get scores
    backtesting_transform(strategy=args.strategy)

    # 6. Run backtester
    backtesting_v2(strategy_config=strategy_config, strategy_name=args.strategy)

