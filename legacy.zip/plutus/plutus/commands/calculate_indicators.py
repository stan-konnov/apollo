import argparse
import boto3
import configparser
import json
import numpy as np
import os
import pandas as pd
from datetime import datetime, timedelta
from multiprocessing import Pool

from plutus.code.calc import (
    PriceChannelCalculator,
    DistributionMomentsCalculator,
    SupportAndResistanceCalculator,
    RelativeStrengthIndexCalculator
)

from plutus.code.signal_marker import SignalMarker

INSTANCE_TYPE_MAP = {
    "ml.t3.xlarge": 4,
    "ml.c5.4xlarge": 16,
    "ml.c5.9xlarge": 36,
    "ml.c5.18xlarge": 72,
}

# Config file settings
# TODO: wrap this up into a function or something in utils
config = configparser.ConfigParser()
config.read("../../config.ini")

ohlcv_file = config["pipeline"]["ohlcv_file"]
temp_path = config["pipeline"]["temp_file_path"]
bucket = config["pipeline"]["bucket"]
region = config["pipeline"]["aws_region"]
configured_size = int(config["pipeline"]["rolling_window_size"])
calc_instance_type = config["pipeline"]["calc_instance_type"]
calc_task_args_file = config["pipeline"]["calc_task_args_file"]
train_indicator_output_prefix = config["pipeline"]["train_indicator_output_prefix"]
bt_indicator_output_prefix = config["pipeline"]["bt_indicator_output_prefix"]

input_path = f"{temp_path}/input"
output_path = f"{temp_path}/output"


def calculate_indicators(id: int, input_file: str, stage: str) -> None:

    start_time = datetime.now()
    print(f"Starting task {id} at {start_time.strftime('%m/%d/%Y, %H:%M:%S')}")

    ohlcv_file_local = f"{input_path}/{ohlcv_file}"

    # Create temp file path
    for path in [input_path, output_path]:
        if not os.path.exists(path):
            os.makedirs(path)

    # Disable SettingWithCopyWarning
    pd.options.mode.chained_assignment = None

    # Map incoming slice to pandas dataframe
    slice = pd.read_csv(f"{input_path}/{input_file}")
    slice.set_index(keys='index', drop=True, inplace=True)
    slice.insert(0, 'action', np.zeros(slice.shape[0]))

    # Initialize calculators
    pc_calculator = PriceChannelCalculator()
    dm_calculator = DistributionMomentsCalculator()
    sr_calculator = SupportAndResistanceCalculator()
    rsi_calculator = RelativeStrengthIndexCalculator()

    # Initialize signal marker
    signal_marker = SignalMarker()

    # Starting index of the window
    window_start = 0

    # Ending index of the window
    window_end = configured_size

    # Construct initial window
    rolling_window = slice.iloc[window_start : window_end]

    # Get the length of the window
    rolling_window_size = rolling_window.shape[0]

    # Declare master dataframe to compute
    # and ultimately write to the output
    master_dataframe = None

    # While window size matches size provided via arguments
    while rolling_window_size == configured_size:

        # Pass window to calculators
        dm_calculator.dataframe = rolling_window
        sr_calculator.dataframe = rolling_window
        rsi_calculator.dataframe = rolling_window
        pc_calculator.dataframe = rolling_window

        # Pass window to signal marker
        signal_marker.dataframe = rolling_window

        # Pass empty array of (manual) markers
        # NOTE: we do not apply this at present
        signal_marker.markers = []

        # Calculate rolling values
        pc_calculator.calculate_price_channel()
        dm_calculator.calculate_moving_dist_moments()
        sr_calculator.calculate_sr_levels()
        rsi_calculator.calculate_rsi()

        # Mark signals on the window
        # NOTE: we pass truthy boolean literal
        # to indicate that indicators must be applied
        signal_marker.mark_signals(True)

        # If we are processing first window
        if master_dataframe is None:

            # Write first processed window into master dataframe
            master_dataframe = rolling_window.copy()

            # Expand it to the length of provided slice
            master_dataframe.reindex(range(len(slice)), fill_value=0)

        else:

            # Otherwise, mount next processed window on top of it,
            # making sure to not override previously set rows and columns
            # NOTE: effectively adding last computed row from processed window
            master_dataframe = master_dataframe.combine_first(rolling_window)

        # Recalculate indices
        window_start += 1
        window_end += 1

        # Construct next window, shifting one minute into the future
        rolling_window = slice.iloc[window_start : window_end]

        # Recalculate window size
        rolling_window_size = rolling_window.shape[0]

    # Drop first rolling window from results
    final_dataframe = master_dataframe[configured_size:]

    # Write csv to disk (sagemaker pipeline will copy it to s3)
    if stage == 'training':
        output_prefix = train_indicator_output_prefix
    elif stage == 'backtesting':
        output_prefix = bt_indicator_output_prefix

    final_dataframe.to_csv(f"{output_path}/{output_prefix}{id}.csv", header=True)

    print(f"wrote {output_path}/{output_prefix}{id}.csv")

    end_time = datetime.now()
    execution_time = end_time - start_time
    print(f"{stage} task {id} done at {end_time.strftime('%m/%d/%Y, %H:%M:%S')} in {str(execution_time)}")


def main(job_id: int, strategy: str) -> None:

    bucket_prefix = f"{strategy}/"

    start_time = datetime.now()
    print(f"Starting indicator calc at {start_time.strftime('%m/%d/%Y, %H:%M:%S')}")

    task_arg_file_local = f"{input_path}/{calc_task_args_file}"

    s3_client = boto3.client("s3")
    s3_client.download_file(bucket, f"{bucket_prefix}{calc_task_args_file}", task_arg_file_local)

    # Index of the task_arg file corresponds with the job_id
    with open(task_arg_file_local, 'r') as file_handle:
        task_arg_list = json.load(file_handle)[job_id]

    with Pool(processes=INSTANCE_TYPE_MAP[calc_instance_type]) as pool:
        pool.starmap(calculate_indicators, task_arg_list)

    end_time = datetime.now()
    execution_time = end_time - start_time
    print(f"Indicator calc completed at {end_time.strftime('%m/%d/%Y, %H:%M:%S')} in {str(execution_time)}")


if __name__ == '__main__':

    # TASK_ARG_INDEX is the index of the task_arg_list assigned to this
    # instance/job.

    job_id = int(os.getenv('TASK_ARG_INDEX'))
    strategy = os.getenv('STRATEGY')
    main(job_id, strategy)