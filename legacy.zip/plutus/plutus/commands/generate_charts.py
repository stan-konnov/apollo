# This is the old chart generator.  We'll leave it off of the
# pipeline for now, since it probably isn't usable as-is.  We
# probably need to generate a different chart per day to make
# it human-readable.  Moving to a more sophisticated charting
# tool is also an option.  Leaving this code here to use as a
# reference for now.

import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go

from datetime import datetime

# TODO
# un-hardcode these things
TEMP_PATH = "../outputs/"
backtesting_results_file = "aapl-backtesting-final.csv"

# Generate png charts and upload them to S3
print("Generating PNG charts")

df = pd.read_csv(f"{TEMP_PATH}{backtesting_results_file}")

# Drop old indices
del df[df.columns[0]]

# Add missing (only necessary) columns
columns = [
    'score',
    'ticker',
    'datetime',
    'open',
    'high',
    'low',
    'close',
    'volume',
]

additional_columns = len(df. columns) - len(columns)

for index in range(0, additional_columns):

    columns.append(index)

print(columns)

df.columns = columns

tickers = df['ticker'].unique()

for ticker in tickers:

    # Dataframe for this ticker
    ticker_df: pd.DataFrame = df.loc[df['ticker'] == ticker]

    # Map datetime string to datetime objects
    start = datetime.strptime(ticker_df['datetime'].values[0], '%Y-%m-%d %H:%M:%S')
    end = datetime.strptime(ticker_df['datetime'].values[-1], '%Y-%m-%d %H:%M:%S')

    # Format back to string avoiding time
    start = datetime.strftime(start, '%Y-%m-%d')
    end = datetime.strftime(end, '%Y-%m-%d')

    # If it's one day backtesting
    # slice out market hours only
    if start == end:

        # Set datetime as index
        ticker_df.set_index('datetime', inplace=True)

        # Slice
        ticker_df = ticker_df.loc[f'{start} 13:30':f'{end} 20:00']

        # Reset back
        ticker_df.reset_index(inplace=True)

    # Define x-axis
    x=ticker_df.index.values

    # Define y-axices for close and score
    y1=ticker_df['close'].values
    y2=ticker_df['score'].values

    # Create the first trace with the primary y-axis
    trace1 = go.Scatter(x=x, y=y1, name='Close')

    # Create the second trace with the secondary y-axis
    trace2 = go.Scatter(x=x, y=y2, name='score', yaxis='y2')

    # Label highest score
    max_index = ticker_df['score'].idxmax()
    highest_score = format(ticker_df['score'][max_index], ".4f")

    # Create the layout with two y-axes
    layout = go.Layout(
        title=f"{ticker_df['ticker'].values[0]} {ticker_df['datetime'].values[0]} - {ticker_df['datetime'].values[-1]}  Highest Score: {highest_score}",
        yaxis=dict(),
        yaxis2=dict(overlaying='y', side='right'),
        height=650
    )

    # Create the figure and add traces to it
    fig = go.Figure(data=[trace1, trace2], layout=layout)

    # Name to save chart under
    chart_name = f"backtesting {ticker_df['ticker'].values[0]} {ticker_df['datetime'].values[0]} - {ticker_df['datetime'].values[-1]}.png"

    # Define path to save the chart
    local_bt_chart = f"{TEMP_PATH}{chart_name}"

    fig.write_image(
        local_bt_chart,
        width=1920,
        height=1080
    )

    s3.upload_file(
        local_bt_chart,
        BUCKET,
        f"{RESULTS_PREFIX}{model_name}/{chart_name}"
    )

### chart original training CSV

# Drop old indices
del data[data.columns[0]]

data.head()
print(data)

fig, ax = plt.subplots(figsize=(20, 8))
fig.subplots_adjust(right=0.75)

twin1 = ax.twinx()

p1, = ax.plot(data['close'], "b-", label="Close")
p2, = twin1.plot(data['action'], "r-", label="score")

twin1.set_ylim(-1, 2)

ax.set_xlabel("Index")
ax.set_ylabel("Close")
twin1.set_ylabel("score")

ax.yaxis.label.set_color(p1.get_color())
twin1.yaxis.label.set_color(p2.get_color())


tkw = dict(size=4, width=1.5)
ax.tick_params(axis='y', colors=p1.get_color(), **tkw)
twin1.tick_params(axis='y', colors=p2.get_color(), **tkw)

ax.tick_params(axis='x', **tkw)

ax.legend(handles=[p1, p2])

local_training_chart = f'{TEMP_PATH}training.png'
plt.savefig(local_training_chart)

s3.upload_file(
    local_training_chart,
    BUCKET,
    f"{RESULTS_PREFIX}{model_name}/training.png"
)
