# This should be refactored to not use sagemaker pipelines.
# It's inefficient to develop on due to needing 10-15 minutes
# of warm-up time per pipeline step, and it is poorly documented.
# Either another framework or just rolling our own is recommended
# for future development.

import json
import os
import time
from datetime import datetime, timedelta
from sagemaker import LinearLearner
from sagemaker.inputs import TrainingInput
from sagemaker.processing import ProcessingInput, ProcessingOutput, Processor
from sagemaker.network import NetworkConfig
from sagemaker.workflow.steps import ProcessingStep, TrainingStep
from sagemaker.workflow.pipeline import Pipeline

ROLE = "arn:aws:iam::584159534805:role/plutus-pipeline"

#TODO make the following a configurable thing (maybe an env var)
ROLE = "arn:aws:iam::584159534805:role/plutus-pipeline"
IMAGE_URI = "584159534805.dkr.ecr.eu-central-1.amazonaws.com/stocks-plutus"
job_timestamp = datetime.now().strftime('%Y%M%dT%H%M%S')

network_config = NetworkConfig(
    security_group_ids=["sg-0cd9f2d918a1e24bb"],
    subnets=["subnet-083d5b294303631ef"]
)

# preprocessing
# Fetches the OHLCV values for a strategy in 1 CSV file
# Calculates indicators
# prepares data files for training job

print(f"{datetime.now().strftime('%m/%d/%Y, %H:%M:%S')} Defining data pre-processor")

one_step = Processor(
    role=ROLE,
    image_uri=IMAGE_URI,
    entrypoint=["docker_cmd/pipeline_step.sh"],
    instance_count=1,
    instance_type="ml.t3.medium",
    env={
        "STRATEGY": os.getenv('STRATEGY'),
        "DATABASE_URL": os.getenv('DATABASE_URL'),
        "MONGO_DATABASE": os.getenv('MONGO_DATABASE'),
        "MONGO_HOST": os.getenv('MONGO_HOST'),
        "MONGO_PORT": os.getenv('MONGO_PORT'),
        "MONGO_PROTOCOL": os.getenv('MONGO_PROTOCOL'),
        "MONGO_USERNAME": os.getenv('MONGO_USERNAME'),
        "MONGO_PASSWORD": os.getenv('MONGO_PASSWORD'),
        "EXCHANGE_OT_URL": os.getenv('EXCHANGE_OT_URL'),
        "PRICES_API_TOKEN": os.getenv('PRICES_API_TOKEN'),
        "PRICES_API_URL": os.getenv('PRICES_API_URL'),
        "ML_S3_BUCKET": os.getenv('ML_S3_BUCKET'),

    },
    network_config=network_config,
)

one_step = ProcessingStep(
    name="Pipeline",
    processor=one_step,
)

# Define and run pipeline

# The Pipeline constructor defines, but does not create, the pipeline resource in AWS
# Note that pipelines are a long-lived resource in AWS that can be listed with a list-pipelines
# CLI or boto3 operation

# Note: remove the sagemaker pipeline step and just run it as a single
# container.  See comment at the top.
pipeline = Pipeline(
    name=f"stocks-plutus",
    parameters=[],
    steps=[
        one_step,
    ],
)

# Examine the JSON pipeline definition to ensure that it's well-formed
print(json.loads(pipeline.definition()))

# Upsert creates or updates the pipeline resource in AWS
# with the definition defined in the Pipeline constructor.
# The start() method runs the pipeline as defined in AWS (not necessarily
# what's defined in the Pipeline constructor).
pipeline.upsert(role_arn=ROLE)

start_time = datetime.now()
print(f"Starting pipeline at {start_time.strftime('%m/%d/%Y, %H:%M:%S')}")
execution = pipeline.start()

# Waiting for the pipline execution to finish is not necessary.
# It will execute all steps even if this script terminates.
# We're waiting here just to record the pipeline execution time to log it.
execution.wait()
end_time = datetime.now() 
execution_time = end_time - start_time
print(f"Pipeline completed at {end_time.strftime('%m/%d/%Y, %H:%M:%S')} in {str(execution_time)}")