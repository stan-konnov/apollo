import os
import importlib

import pandas as pd

from backtesting import Backtest
from dotenv import load_dotenv

from plutus.code.api_connector import ApiConnector
from plutus.code.backtesting_results_v2 import Mutator, StrategyBacktesting

def __strip_market_hours(dataframe: pd.DataFrame) -> pd.DataFrame:

    # Intermediary column that holds time of logged OHLCV
    dataframe['time'] = dataframe['datetime'].dt.strftime('%H:%M:%S')

    # Filter out only those rows that fall into valid market hours
    market_hours_only = dataframe[
        ('09:30:00' <= dataframe['time']) & (dataframe['time'] <= '16:00:00')
    ]

    # Drop intermediary column
    market_hours_only = market_hours_only.drop(columns=['time'])

    return market_hours_only


def main():

    load_dotenv()

    # Configuration for api connector
    ticker = 'SPY'
    # start_date = '2007-01-03-00:00'
    # end_date = '2012-12-29-00:00'
    # start_date = '2023-04-28-00:00'
    # end_date = '2023-06-01-00:00'
    start_date = '2024-01-05-00:00'
    end_date = '2024-01-06-00:00'

    window_size = 125

    # Configure api connector
    api_connector = ApiConnector()
    api_connector.ticker = ticker
    api_connector.start_date = start_date
    api_connector.end_date = end_date

    # Request or read and prepare
    dataframe = api_connector.request_daily_prices()
    dataframe = __strip_market_hours(dataframe)

    print(dataframe)

    # Initialize strategy
    strategy_file = 'custom_long'
    strategy_name = 'CustomLongStrategy'

    strategy_module = importlib.import_module(f'plutus.code.strategies.{strategy_file}')
    strategy_class = getattr(strategy_module, strategy_name)
    strategy = strategy_class()

    # Process
    strategy.consume(ticker, dataframe, window_size)
    strategy.calculate()
    strategy.mark_signals()
    strategy.clean()

    print(strategy.dataframe)

    # Calculate signal ratio
    d = strategy.dataframe
    sig_ratio = len(d[d['action'] == 1.0]) / len(d) * 100

    print(f'Signal Ratio: {sig_ratio}')

    # Write to file system
    strategy.dataframe.to_csv(os.getcwd() + f'/../outputs/{ticker}:{strategy_name}.csv')

    # Prepare dataframe for backtesting
    input_file = 'SPY:CustomLongStrategy.csv'
    mutator = Mutator()
    mutator.dataframe = pd.read_csv(f'../outputs/{input_file}')
    mutator.is_local = True
    mutator.prepare()

    # Backtest and consume the stats for each configured tuple
    # of: (window_size, stop_loss, take_profit, signal_threshold)
    configurations = [
        (180, 0.02, 0.01, 1.0),
        # (180, 0.02, 0.02, 1.0),
        # (180, 0.02, 0.03, 1.0)
    ]

    for ws, sl, tp, st in configurations:

        StrategyBacktesting.window_size = ws
        StrategyBacktesting.stop_loss_level = sl
        StrategyBacktesting.take_profit_level = tp
        StrategyBacktesting.signal_threshold = st

        bt = Backtest(mutator.dataframe, StrategyBacktesting, cash=1000)
        stats = bt.run()
        print(stats)


if __name__ == '__main__':

    main()