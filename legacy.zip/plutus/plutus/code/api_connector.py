import arrow
import os
import pytz
import requests

import pandas as pd

from datetime import datetime
from dateutil.relativedelta import relativedelta
from pandas.core.frame import DataFrame
from urllib.parse import urlencode, quote_plus

from .database_layer import DatabaseLayer

class ApiConnector:

    # Ticker to request prices for
    ticker: str = None

    # Start point to request prices from (inclusive)
    start_date: str = None

    # Cutoff point until which to request prices (exclusive)
    end_date: str = None

    # Number of periods to request prices over (used in yahoo os)
    n_periods: int = None

    # Interval to use for day trading
    day_trading_interval: str = '1m'

    # Database layer to read/write prices
    dbl = DatabaseLayer()

    # Number of days we can request at once
    api_limit: int = 120


    def __init__(self) -> None:

        # Load necessary env variables
        self.PRICES_API_URL = os.getenv('PRICES_API_URL')
        self.PRICES_API_TOKEN = os.getenv('PRICES_API_TOKEN')
        self.PRICES_API_LIVE_URL = os.getenv('PRICES_API_LIVE_URL')
        self.PRICES_API_LIVE_TOKEN = os.getenv('PRICES_API_LIVE_TOKEN')
        self.EXCHANGE_OT_URL = os.getenv('EXCHANGE_OT_URL')


    def request_daily_prices(self) -> DataFrame:

        # Start and end as datetime objects
        start_dt = self.__to_datetime(self.start_date)
        end_dt = self.__to_datetime(self.end_date)

        # Get exchange holidays
        exchange_holidays = self.get_exchange_holidays()

        # Get start day of the week
        wd = datetime.weekday(start_dt)

        # Handle the weekend and exchange holiday case
        # Move forward (not backward) to the next trading day
        # moving backwards can add unexpected dates outside of the
        # requested time period and cause problems.
        
        # Whie starting point falls on exchange holidays or is weekend
        while start_dt.strftime('%Y-%m-%d') in exchange_holidays or wd in (5, 6):

            # Move forward by one day
            start_dt = start_dt + relativedelta(days=1)

            # Recalculate new day of the week
            wd = datetime.weekday(start_dt)

            print('Start falls on holidays or weekend, moving forward')
            print(f'New start {start_dt}')

        # Check if prices for requested interval are available on disk
        prices_available = self.dbl.check_prices(self.ticker, start_dt, end_dt)

        # If prices are on disk
        if prices_available:

            print(f'Price for {self.ticker} are available on disk. Reading')

            # Read them
            prices = self.dbl.read_prices(self.ticker, start_dt, end_dt)

            # Convert into dataframe
            dataframe = pd.DataFrame(prices)

            return dataframe

        # Otherwise, request prices
        print(f'Price for {self.ticker} are missing')

        # Time delta between start and end in days
        dt_delta = (end_dt - start_dt).days

        # If it's a small period
        if dt_delta < self.api_limit:

            print(f"Requesting {self.ticker} from {start_dt} up to {end_dt}")

            # Request prices
            price_slice = self.__req_prices(start_dt, end_dt)

            # Save prices
            self.dbl.write_prices(self.ticker, price_slice)

            # Read them back, to ensure shape we define in read method
            prices = self.dbl.read_prices(self.ticker, start_dt, end_dt)

            # Convert into dataframe
            dataframe = pd.DataFrame(prices)

            return dataframe

        # Otherwise, it's a larger period

        # Moving starting point
        mov_start_dt = start_dt

        # List to hold incoming prices
        prices = []

        # While delta is higher than API limit
        while dt_delta > self.api_limit:

            # Construct slice in time of 120 days
            # Starting from provided start date argument
            cutoff = mov_start_dt + relativedelta(days=self.api_limit)

            print(f"Requesting {self.ticker} from {mov_start_dt} up to {cutoff}")

            # Request prices
            price_slice = self.__req_prices(mov_start_dt, cutoff)

            # Add to list
            prices.extend(price_slice)

            # Start next slice at the cutoff point
            mov_start_dt = cutoff

            # Recalculate delta
            dt_delta = (end_dt - mov_start_dt).days

            # If leftover days
            if dt_delta <= self.api_limit and dt_delta != 0:

                print('Leftover:')
                print(f"Requesting {self.ticker} from {mov_start_dt} up to {end_dt}")

                price_slice = self.__req_prices(mov_start_dt, end_dt)

                prices.extend(price_slice)

        # Write prices to disk
        self.dbl.write_prices(self.ticker, prices)

        # Read them back, to ensure shape we define in read method
        prices = self.dbl.read_prices(self.ticker, start_dt, end_dt)

        # Convert into dataframe
        prices_list = [price for price in prices]
        dataframe = pd.DataFrame(prices_list)

        return dataframe


    def get_exchange_holidays(self) -> list[str]:

        # Request market open times
        response = requests.get(f'{self.EXCHANGE_OT_URL}?api_token={self.PRICES_API_TOKEN}')

        # Map to json
        response_json = response.json()

        # Extract exchange holidays from response
        holidays = [v['Date'] for v in response_json['ExchangeHolidays'].values()]

        return holidays


    def request_latest_bar(self, ticker: str) -> pd.DataFrame:

        # Construct querystring
        qs = urlencode(
            {
                'access_key': self.PRICES_API_LIVE_TOKEN,
                'symbols': ticker,
                'interval': '1min',
                'limit': '1'
            },
            quote_via=quote_plus
        )

        # Concatenate with base path
        request_url = f'{self.PRICES_API_LIVE_URL}?{qs}'

        # Request latest price
        response = requests.get(request_url)

        # Map to json
        response_json = response.json()

        return response_json


    def __to_datetime(self, dt_string: str) -> datetime:

        # Return datetime object
        return datetime.strptime(dt_string, '%Y-%m-%d-%H:%M')


    def __to_unix_timestamp(self, dt: datetime) -> str:

        # UTC aware datetime
        et_dt = dt.replace(tzinfo=pytz.utc)

        # To unix time
        unix_time = arrow.get(et_dt).timestamp()

        # Return as string to feed into query
        return str(unix_time)


    def __req_prices(self, start: datetime, end: datetime) -> list[dict]:

        base = f"""
        {self.PRICES_API_URL}/{self.ticker}.US
        ?api_token={self.PRICES_API_TOKEN}
        &interval={self.day_trading_interval}
        &fmt=json
        """

        # Margins as unix time
        str_ut = self.__to_unix_timestamp(start)
        end_ut = self.__to_unix_timestamp(end)

        # Querystring chunk
        from_to_qs = urlencode(
            { 'from': str_ut, 'to': end_ut },
            quote_via=quote_plus
        )

        # Request prices
        response = requests.get(f'{base}&{from_to_qs}')

        # Map to json
        response_json = response.json()

        return response_json