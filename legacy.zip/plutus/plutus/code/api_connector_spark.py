import arrow
import json
import os
import pytz
import requests

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    TimestampType,
)

from datetime import datetime
from dateutil.relativedelta import relativedelta

from .database_layer_spark import DatabaseLayer

class ApiConnector:

    ## Class vars for unlikely-to-change constants

    # Number of days we can request at once
    api_limit: int = 120

    # API base URL for historical data
    eod_base_url: str = 'https://eodhistoricaldata.com'

    # API base URL for exchange holidays, etc.
    marketstack_base_url: str = 'https://api.marketstack.com'


    def __init__(
        self,
        spark: SparkSession, 
        eod_token: str,
        marketstack_token: str,
        mongo_database: str,
        database_url: str,
        ticker: str,
        start_date: str,
        end_date: str,
        day_trading_interval: str = '1m',
    ) -> None:

        self.eod_token = eod_token
        self.marketstack_token = marketstack_token

        # Database layer to read/write prices
        self.dbl = DatabaseLayer(mongo_database, database_url)

        # Spark SQL Session to be passed from outside this obj
        self.spark = spark

        # Ticker to request prices for
        self.ticker = ticker

        # Start point to request prices from (inclusive)
        self.start_date = start_date

        # Cutoff point until which to request prices (exclusive)
        self.end_date = end_date

        # Interval to use for day trading
        self.day_trading_interval = day_trading_interval


    @staticmethod
    def get_schema() -> StructType:
        """Defines the OHLCV dataframe schema (without indicators)"""

        # Prices need to be initially imported as strings and casted
        # after because spark columns are strongly typed, and it fails
        # because some of the prices look like integers even though we
        # want floats or doubles.
        schema = StructType([
            StructField("ticker", StringType(), True),
            StructField("time_period", StringType(), True),

            # TimestampType is not time zone aware.  Note when it is printed,
            # it marks it as UTC/Z time, but that should be ignored - it is
            # just whatever datetime was passed in.  At this time, the
            # database layer converts everything to US/Eastern, so this
            # datetime(TimestampType) is also in US/Eastern for now.
            StructField("datetime", TimestampType(), True),
            StructField("open", StringType(), True),
            StructField("high", StringType(), True),
            StructField("low", StringType(), True),
            StructField("close", StringType(), True),
            StructField("volume", IntegerType(), True),
        ])

        return schema


    def create_spark_df(self, prices) -> DataFrame:

        df = self.spark.createDataFrame(
            [x for x in prices], ApiConnector.get_schema()
        )

        df = df.withColumn('ticker', lit(self.ticker))
        df = df.withColumn('time_period', lit(f'{self.start_date} {self.end_date}'))

        # get_schema initially sets these as StringType, as pyspark has
        # trouble implicitly casting these (thinking that some are ints
        # and some are doubles).  There is probably a better way of doing
        # this, but this works for now.
        df = df.withColumn('open', col('open').cast(DoubleType()))
        df = df.withColumn('high', col('high').cast(DoubleType()))
        df = df.withColumn('low', col('low').cast(DoubleType()))
        df = df.withColumn('close', col('close').cast(DoubleType()))

        return df


    def request_daily_prices(self) -> DataFrame:

        # Start and end as datetime objects
        start_dt = self.__to_datetime(self.start_date)
        end_dt = self.__to_datetime(self.end_date)

        # Adjust the start time (forward) if it falls on a weekend
        # or exchange holiday.  The end time doesn't matter here, but
        # it is adjusted backwards if needed (e.g. in the database layer).
        start_dt = self.__adjust_start_date(start_dt)

        # Check if prices for requested interval are available on disk
        prices_available = self.dbl.check_prices(self.ticker, start_dt, end_dt)

        # If prices are on disk
        if prices_available:

            print(f'Prices for {self.ticker} are available on disk. Reading')

            # Read them
            prices = self.dbl.read_prices(self.ticker, start_dt, end_dt)

            # Convert into dataframe
            dataframe = self.create_spark_df(prices)

            return dataframe

        # Otherwise, request prices
        print(f'Prices for {self.ticker} are missing')

        # Time delta between start and end in days
        dt_delta = (end_dt - start_dt).days

        # If it's a small period
        if dt_delta < ApiConnector.api_limit:

            print(f"Requesting {self.ticker} from {start_dt} up to {end_dt}")

            # Request prices
            price_slice = self.__req_prices(start_dt, end_dt)

            # Save prices
            self.dbl.write_prices(self.ticker, price_slice)

            # Read them back, to ensure shape we define in read method
            prices = self.dbl.read_prices(self.ticker, start_dt, end_dt)

            # Convert into dataframe
            dataframe = self.create_spark_df(prices)

            return dataframe

        # Otherwise, it's a larger period

        # Moving starting point
        mov_start_dt = start_dt

        # List to hold incoming prices
        prices = []

        # While delta is higher than API limit
        while dt_delta > ApiConnector.api_limit:

            # Construct slice in time of 120 days
            # Starting from provided start date argument
            cutoff = mov_start_dt + relativedelta(days=ApiConnector.api_limit)

            print(f"Requesting {self.ticker} from {mov_start_dt} up to {cutoff}")

            # Request prices
            price_slice = self.__req_prices(mov_start_dt, cutoff)

            # Add to list
            prices.extend(price_slice)

            # Start next slice at the cutoff point
            mov_start_dt = cutoff

            # Recalculate delta
            dt_delta = (end_dt - mov_start_dt).days

            # If leftover days
            if dt_delta <= ApiConnector.api_limit and dt_delta != 0:

                print('Leftover:')
                print(f"Requesting {self.ticker} from {mov_start_dt} up to {end_dt}")

                price_slice = self.__req_prices(mov_start_dt, end_dt)

                prices.extend(price_slice)

        # Write prices to disk
        self.dbl.write_prices(self.ticker, prices)

        # Read them back, to ensure shape we define in read method
        prices = self.dbl.read_prices(self.ticker, start_dt, end_dt)

        # Convert into dataframe
        prices_list = [price for price in prices]
        dataframe = self.create_spark_df(prices_list)

        return dataframe


    def get_exchange_holidays(self) -> list:

        exchange_ot_url = f"{ApiConnector.eod_base_url}/api/exchange-details/US"

        payload = {'api_token': self.eod_token}

        # Request market open times
        response = requests.get(exchange_ot_url, params=payload)

        # Map to json
        response_json = response.json()

        # Extract exchange holidays from response
        holidays = [v['Date'] for v in response_json['ExchangeHolidays'].values()]

        return holidays


    def __adjust_start_date(self, start_dt: datetime) -> datetime:

        # Get exchange holidays
        exchange_holidays = self.get_exchange_holidays()

        # Get integer representing day of the week (0 - 6)
        wd = datetime.weekday(start_dt)

        # Handle the weekend and exchange holiday case
        # Move forward (not backward) to the next trading day
        # moving backwards can add unexpected dates outside of the
        # requested time period and cause problems.
        
        # Whie starting point falls on exchange holidays or is weekend
        while start_dt.strftime('%Y-%m-%d') in exchange_holidays or wd in (5, 6):

            # Move forward by one day
            start_dt = start_dt + relativedelta(days=1)

            # Recalculate new day of the week
            wd = datetime.weekday(start_dt)

            print('Start falls on holidays or weekend, moving forward')
            print(f'New start {start_dt}')

        return start_dt

    def request_latest_bar(self, ticker: str) -> DataFrame:

        # Construct querystring
        payload = {
            'access_key': self.marketstack_token,
            'symbols': ticker,
            'interval': '1min',
            'limit': '1'
        }

        # Request latest price
        response = requests.get(
            f"{ApiConnector.marketstack_base_url}/v1/intraday",
            params=payload,
        )

        # Map to json
        response_json = response.json()

        return response_json


    def __to_datetime(self, dt_string: str) -> datetime:

        # Return datetime object
        return datetime.strptime(dt_string, '%Y-%m-%d-%H:%M')


    def __to_unix_timestamp(self, dt: datetime) -> str:

        # UTC aware datetime
        et_dt = dt.replace(tzinfo=pytz.utc)

        # To unix time
        unix_time = arrow.get(et_dt).timestamp()

        # Return as string to feed into query
        return str(unix_time)


    def __req_prices(self, start: datetime, end: datetime) -> list:

        base_url = f"{ApiConnector.eod_base_url}/api/intraday/{self.ticker}.US"

        # time periods as unix time
        str_ut = self.__to_unix_timestamp(start)
        end_ut = self.__to_unix_timestamp(end)

        payload = {
            'api_token': self.eod_token,
            'interval': self.day_trading_interval,
            'fmt': 'json',
            'from': str_ut,
            'to': end_ut,
        }

        # Request prices
        response = requests.get(base_url, params=payload)

        # Map to json
        response_json = response.json()

        return response_json