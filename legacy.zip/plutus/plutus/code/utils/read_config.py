import json
import os

def read_config_file(strategy: str, spark: bool = False) -> dict:
    """Read config from file system"""

    # EMR spark step jobs have a --files option that will copy
    # files from s3 to the local current working directory of the
    # spark step job.  Non-spark jobs can get the json from the
    # config directory.
    if spark:
        config_file_path = f"{strategy}.json"
    else:
        config_file_path = f"../config/{strategy}.json"

    with open(config_file_path) as strat_file:
        return json.load(strat_file)