import pandas as pd

from plutus.code.api_connector import ApiConnector


def __strip_market_hours(dataframe: pd.DataFrame) -> pd.DataFrame:

    # Intermediary column that holds time of logged OHLCV
    dataframe['time'] = dataframe['datetime'].dt.strftime('%H:%M:%S')

    # Filter out only those rows that fall into valid market hours
    market_hours_only = dataframe[
        ('09:30:00' <= dataframe['time']) & (dataframe['time'] <= '16:00:00')
    ]

    # Drop intermediary column
    market_hours_only = market_hours_only.drop(columns=['time'])

    return market_hours_only


def __write_to_input_file(path: str, input_dataframe: pd.DataFrame) -> None:

    input_dataframe.to_csv(path, header=True)


def create_single_series_input(path: str, ticker: str, start_date: str, end_date: str) -> None:

    # Initialize connector with provided config
    api_connector = ApiConnector()
    api_connector.ticker = ticker
    api_connector.start_date = start_date
    api_connector.end_date = end_date

    # Request OHLCV by provided values
    initial_time_series = api_connector.request_daily_prices()

    # Filter out only those rows that fall into valid market hours
    market_hours_only = __strip_market_hours(initial_time_series)

    # Write inputs for further processing
    __write_to_input_file(path, market_hours_only)


def create_multiple_series_input(path: str, configs: list[tuple[str, str, str]]) -> None:

    # List to hold multiple time series
    time_series: list[pd.DataFrame] = []

    # Initialize connector
    api_connector = ApiConnector()

    # Loop through configurations
    for config in configs:

        # Unpack them
        ticker, start_date, end_date = config

        # Provide them to the connector
        api_connector.ticker = ticker
        api_connector.start_date = start_date
        api_connector.end_date = end_date

        # Request OHLCV by provided values
        initial_time_series = api_connector.request_daily_prices()

        # Filter out only those rows that fall into valid market hours
        market_hours_only = __strip_market_hours(initial_time_series)

        # Add ticker column to the time-series
        market_hours_only.insert(0, 'ticker', ticker)

        # Add indexer column to the time-series
        market_hours_only.insert(1, 'time_period', f'{start_date} {end_date}')

        # Add shaped time series to the list
        time_series.append(market_hours_only)

    # Merge constructed dataframes into one
    combined_inputs = pd.concat(time_series, ignore_index=True)

    # Write combined inputs for further processing
    __write_to_input_file(path, combined_inputs)