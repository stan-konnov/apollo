from datetime import datetime, time

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.types import BooleanType

from plutus.code.api_connector_spark import ApiConnector


@udf(returnType=BooleanType())
def market_hours_filter(timestamp) -> bool:
    opening_time = datetime.strptime('09:30', '%H:%M').time()
    closing_time = datetime.strptime('16:00', '%H:%M').time()
    ohlcv_time = timestamp.time()

    return opening_time <= ohlcv_time and ohlcv_time <= closing_time


def create_single_series_input(
    spark: SparkSession,
    ticker: str,
    start_date: str,
    end_date: str,
    eod_token: str,
    marketstack_token: str,
    mongo_database: str,
    database_url: str,
) -> DataFrame:

    # Initialize connector with provided config
    api_connector = ApiConnector(
        spark=spark,
        eod_token=eod_token,
        marketstack_token=marketstack_token,
        mongo_database=mongo_database,
        database_url=database_url,
        ticker=ticker,
        start_date=start_date,
        end_date=end_date,
    )

    # Request OHLCV by provided values
    initial_time_series = api_connector.request_daily_prices()

    # Filter rows that fall into valid market hours
    market_hours_only = initial_time_series.filter(market_hours_filter('datetime'))

    return market_hours_only
