import pandas as pd

def define_final_columns() -> list[str]:

    # TODO: please conditionally in/exclude
    # 'ticker', 'datetime'

    # Return a list of columns we expect in the final dataframe
    return [
        'open', 'high','low', 'close', 'volume',
        'mov_skew', 'mov_kurt', 'mov_avg', 'mov_std', 'lb_slopes', 'lower_bound', 'rsi',
    ]

def normalize(dataframe: pd.DataFrame, drop_action: bool = False) -> pd.DataFrame:

    # Get produced columns
    columns = dataframe.columns.to_list()

    # Loop through columns and move SR levels into separate list
    sr_levels = []

    for column in columns:
        if 'sr_level' in column:
            sr_levels.append(column)

    # Sort extracted SR levels numerically (by last integer)
    sr_levels = sorted(sr_levels, key=lambda x: int(x[len(x) - 1]))

    # Get columns we would like in final dataframe
    columns = define_final_columns()

    # Expand them with SR levels
    columns = columns + sr_levels

    if drop_action:

        columns = columns[1:]

    # Rearrange dataframe columns
    dataframe = dataframe[columns]

    # Fill missing cells across the dataframe with an ignorable value
    dataframe.fillna(-1, inplace=True)

    return dataframe