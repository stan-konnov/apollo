import pandas as pd

from datetime import datetime
from backtesting import Strategy


class Mutator:

    # Dataframe to mutate
    dataframe: pd.DataFrame

    # Flag to decide which column to use for signals (action / score)
    is_local = False

    def prepare(self) -> None:

        self.__rename_colums()
        self.__group_by_unique_date()
        self.__adapt_indices()
        self.__add_eod_datetime()


    def __rename_colums(self) -> None:

        # Pick action / score column based on provided flag
        sig_column = 'action' if self.is_local else 'score'

        # Rename columns to adhere to library signature
        # Using inplace here results in a pandas warning about setting
        # a value on a copy of a slice.  Just reassign it instead

        self.dataframe = self.dataframe.rename(
            columns={
                'open': 'Open',
                'high': 'High',
                'low': 'Low',
                'close': 'Close',
                sig_column: 'signal',
            }
        )


    def __group_by_unique_date(self) -> None:

        # Split datetime string and grab the date value
        # Map it to another column to later group by
        self.dataframe['unique_date'] = self.dataframe['datetime'].apply(
            lambda x: x.split(' ')[0]
        )

    def __adapt_indices(self) -> None:

        # Map datetime string columns to datetime
        self.dataframe['datetime'] = pd.to_datetime(self.dataframe['datetime'])

        # Set datetime as index
        self.dataframe.set_index('datetime', inplace=True)

    def __add_eod_datetime(self) -> None:
        """Also add the datetime of the end of trading day
        
        Simply hardcoding the end time doesn't work due to partial
        trading days
        """

        eod_dt_dict = {}
        for unique_date in self.dataframe['unique_date'].unique():
            eod_dt = self.dataframe.loc[
                self.dataframe['unique_date'] == unique_date
            ].index.max()
            eod_dt_dict[unique_date] = eod_dt

        self.dataframe['eod_datetime'] = (
            self.dataframe['unique_date'].map(eod_dt_dict)
        )


class StrategyBacktesting(Strategy):

    # Stop loss level to use for exits
    stop_loss_level: float = 0.02

    # Take profit level to use for exits
    take_profit_level: float = 0.01

    # Defines numerical threshold of
    # what is considered to be a signal
    signal_threshold: float = 1.0

    # Defines time interval during which
    # signals are valid (default = 180 minutes)
    window_size: int = 180

    # Minutes before EOD time to close all positions
    # Note that this needs to be >= 1, because the
    # Backtesting library does not execute orders until
    # the following minute.
    position_closing_minutes = 10

    # Date string representing group
    # within which we process signals
    currently_processed_group: str = None

    # Map of valid signal windows to filter signals
    valid_signal_windows: dict[str, pd.DataFrame] = {}


    def init(self) -> None:

        # Grab dataframe provided by context
        dataframe = self.data.df

        # Precompute valid signal windows
        for unique_date in dataframe['unique_date'].unique():

            # Slice out valid signal window and save to dict
            signal_window = dataframe[dataframe['unique_date'] == unique_date]

            signal_window = signal_window.iloc[:self.window_size]

            self.valid_signal_windows[unique_date] = signal_window


    @classmethod
    def to_str(cls) -> str:
        """Return configuration for printing or writing"""

        return \
f"""
    Signal Window: {cls.window_size}
    Signal Threshold: {cls.signal_threshold}
    Stop Loss Level: {cls.stop_loss_level}
    Take Profit Level: {cls.take_profit_level}

"""


    def next(self) -> None:

        # Get currently iterated group (day)
        group = self.data['unique_date'][-1]

        # Get currently iterated datetime entry
        # and last datetime entry in the group
        curr_entry_dt = self.data.index[-1]
        last_entry_dt = (
            self.data['eod_datetime'][-1] - 
                pd.Timedelta(minutes=self.position_closing_minutes)
        )

        # Sanity check - no positions should be open
        # at the start of a new day
        if self.currently_processed_group != group:
            assert \
                not self.position, "Position open at beginning of trading day"

        # Get currently iterated signal
        signal = self.data['signal'][-1]

        # Fetch valid signal window for current group
        signal_window = self.valid_signal_windows[group]

        # Check if signal is valid:
        # equal or above threshold and within window
        signal_is_valid = (
            signal >= self.signal_threshold and
            curr_entry_dt in signal_window.index
        )

        # If there is a valid signal and we are processing same group
        if signal_is_valid and self.currently_processed_group == group:

            # If we already have open position (either short or long)
            # Otherwise, skip - we are already inside a trade
            # TODO: probably need to handle short vs. long
            if not self.position:

                # Calculate SL and TP from close
                close = self.data['Close'][-1]

                sl = close * (1 - self.stop_loss_level)
                tp = close * (1 + self.take_profit_level)

                # And open long position
                self.buy(sl=sl, tp=tp)

        # Close all positions at end of trading day
        # This occurs from n minutes before EOD to EOD where
        # n = position_closing_minutes
        # EOD = last minute of the day
        # (the "last minute" is not always the same due to
        # partial trading days)
        # last_entry_dt is the datetime n minutes before EOD
        if curr_entry_dt >= last_entry_dt and self.position:
            self.position.close()

        # Preserve currently iterated group
        self.currently_processed_group = group