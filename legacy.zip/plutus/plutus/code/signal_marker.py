import pandas as pd

from datetime import datetime

class SignalMarker:

    dataframe: pd.DataFrame = None

    markers: list[list[int]] = None

    def mark_signals(self, with_indicators: bool) -> None:

        # List to hold markers' datetime objects
        formatted_markers = []

        # Map markings to yyyy-mm-dd-hh-mm datetimes
        for pair in self.markers:

            pair = list(
                map(lambda x: datetime.strptime(x, '%Y-%m-%d-%H:%M'), pair)
            )

            formatted_markers.append(pair)

        # Get highest support/resistance level
        sr_level = self.__get_sr_level()

        # Loop through frame
        for _, (label, row) in enumerate(self.dataframe.iterrows()):

            if with_indicators:

                # Combine indicators
                indicators_meet = self.__comb_indicators(row, sr_level)

                if indicators_meet:

                    self.dataframe.loc[label, 'action'] = 1.0

            # Grab row datetime
            row_date_time = row['datetime']

            # Loop through each manual marker pair
            for start, end in formatted_markers:

                # If true, or indicators are positive
                if start <= row_date_time <= end:

                    # Mark signal into dataframe
                    self.dataframe.loc[label, 'action'] = 1.0


    def __get_sr_level(self) -> float:

        # Potentially present s/r levels
        # Descending from highest to lowest
        sr_levels = [4, 3, 2, 1]

        # Variable to hold s/r level integer
        sr_level = None

        # Loop through potential levels
        for level in sr_levels:

            # Index the level out from the dataframe
            sr_level = self.dataframe.get(f"sr_level_{level}", None)

            # If level is present
            if sr_level is not None:

                # Grab the value and stop looping
                sr_level = sr_level.values[0]

                break

        return sr_level


    def __comb_indicators(self, row: pd.Series, sr_level: float) -> bool:

        # Grab closing price
        cp = row['close']

        # Grab lower bound value
        lb = row['lower_bound']

        # If below support/resistance:
        # indicating room for appreciation
        upside_present = cp < sr_level

        # If positive moving skewness:
        # price point moving down
        mov_skew_is_positive = row['mov_skew'] > 0

        # If positive moving kurtosis:
        # price point is peaking
        mov_kurt_is_positive = row['mov_kurt'] > 0

        # If positive slope:
        # price point is on the recovery
        slope_is_positive = row['lb_slopes'] > 0

        # If standard deviation of a row is above 1:
        # price point is outside of 68% of normal occurences
        above_one_std = row['mov_std'] > 1

        # If below moving average:
        # there is a potential for mean reversal
        below_mov_avg = cp < row['mov_avg']

        # If close is within 10% of lower channel bound:
        # Price point has a potential to recover from here
        close_to_lower_bound = (abs((cp - lb) / cp) * 100) <= 0.1

        # If RSI below 50: price point is in downtrend
        rsi_in_downtrend = row['rsi'] < 50

        # Combine indicators
        indicators_meet = upside_present and (
            mov_skew_is_positive or
            mov_kurt_is_positive or
            slope_is_positive or
            above_one_std or
            below_mov_avg or
            close_to_lower_bound or
            rsi_in_downtrend
        )

        return indicators_meet