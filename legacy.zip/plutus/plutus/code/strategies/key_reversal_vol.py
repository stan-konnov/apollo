import pandas as pd

from plutus.code.strategies.base import BaseStrategy

from plutus.code.calc.kr import KeyReversalCalculator
from plutus.code.calc.atr import AverageTrueRangeCalculator


class KeyReversalVolatility(BaseStrategy):

    # Calculators used
    kr_c = KeyReversalCalculator()
    at_c = AverageTrueRangeCalculator()


    def consume(self, ticker: str, dataframe: pd.DataFrame, window_size: int) -> None:

        # Pass ticker and dataframe to base class via method
        # and not constructor to avoid redeclaring classes
        # on processing of each slice and cluttering the heap
        BaseStrategy.ticker = ticker
        BaseStrategy.dataframe = dataframe

        # Prepare dataframe for processing
        self.prepare_dataframe()

        # Provide dataframe and window size to calculators
        self.kr_c.dataframe = dataframe
        self.at_c.dataframe = dataframe

        self.at_c.window_size = window_size


    def calculate(self) -> None:

        # Calculate values necessary for given strategy
        self.kr_c.calculate_key_reversals()
        self.at_c.calculate_average_true_range(preserve_tr=True)


    def mark_signals(self) -> None:

        # Loop through frame
        for _, (label, row) in enumerate(self.dataframe.iterrows()):

            # Combine indicators
            indicators_meet = self.__comb_indicators(row)

            if indicators_meet:

                self.dataframe.loc[label, 'action'] = 1.0


    def clean(self) -> None:

        # Remove NaN values from the dataframe
        self.dataframe.dropna(inplace=True)


    def __comb_indicators(self, row: pd.Series) -> bool:

        # Key Reversal bar has taken place
        key_reversal = row['kr'] == 1

        # It is reinforced by volatility:
        # True Range of this bar is higher than 1.5 * ATR
        vol_reinforced = row['tr'] > 1.5 * row['atr']

        # Combine indicators
        indicators_meet = key_reversal and vol_reinforced

        return indicators_meet