import pandas as pd
import numpy as np


class BaseStrategy:

    ticker: str = None

    dataframe: pd.DataFrame = None


    def prepare_dataframe(self) -> None:

        # Avoid inserting columns if we passed first RTP run
        if 'ticker' in self.dataframe:

            return

        # Write ticker and action columns into dataframe
        self.dataframe.insert(0, 'ticker', self.ticker)
        self.dataframe.insert(0, 'action', np.zeros(self.dataframe.shape[0]))