import pandas as pd

from plutus.code.strategies.base import BaseStrategy

from plutus.code.calc.pcv2 import PriceChannelCalculator
from plutus.code.calc.atr import AverageTrueRangeCalculator


class PriceChannel(BaseStrategy):

    pc_c = PriceChannelCalculator()
    at_c = AverageTrueRangeCalculator()


    def consume(self, ticker: str, dataframe: pd.DataFrame, window_size: int) -> None:

        # Pass ticker and dataframe to base class via method
        # and not constructor to avoid redeclaring classes
        # on processing of each slice and cluttering the heap
        BaseStrategy.ticker = ticker
        BaseStrategy.dataframe = dataframe

        # Prepare dataframe for processing
        self.prepare_dataframe()

        # Here we omit providing dataframe
        # to price channel calculator since
        # we need ATR outputs for calculations
        self.at_c.dataframe = dataframe
        self.at_c.window_size = window_size

        # We only provide window
        self.pc_c.window_size = window_size


    def calculate(self) -> None:

        # We first calculate ATR while preserving TR
        self.at_c.calculate_average_true_range(preserve_tr=True)

        # We then provide ATR outputs to price channel calculator
        self.pc_c.dataframe = self.at_c.dataframe

        # And then calculate price channels
        self.pc_c.calculate_price_channels()


    def mark_signals(self) -> None:

        # Loop through frame
        for _, (label, row) in enumerate(self.dataframe.iterrows()):

            # Combine indicators
            indicators_meet = self.__comb_indicators(row)

            if indicators_meet:

                self.dataframe.loc[label, 'action'] = 1.0


    def clean(self) -> None:

        # Remove NaN values from the dataframe
        self.dataframe.dropna(inplace=True)


    def __comb_indicators(self, row: pd.Series) -> bool:

        # Slope of price channel is positive
        slope_is_positive = row['slope'] > 0

        # Current price is below lower bound of price channel
        below_lower_bound = row['close'] < row['l_bound']

        # Current price is above upper bound of price channel
        above_upper_bound = row['close'] > row['u_bound']

        indicators_meet = (
            (slope_is_positive and below_lower_bound) or
            above_upper_bound
        )

        return indicators_meet