import pandas as pd

from plutus.code.strategies.base import BaseStrategy

from plutus.code.calc.sw import SwingsCalculator
from plutus.code.calc.kr import KeyReversalCalculator
from plutus.code.calc.pcv2 import PriceChannelCalculator
from plutus.code.calc.atr import AverageTrueRangeCalculator
from plutus.code.calc.dmv2 import DistributionMomentsCalculator
from plutus.code.calc.rsiv2 import RelativeStrengthIndexCalculator


class CustomLongStrategy(BaseStrategy):

    sw_c = SwingsCalculator()
    kr_c = KeyReversalCalculator()
    pc_c = PriceChannelCalculator()
    at_c = AverageTrueRangeCalculator()
    dm_c = DistributionMomentsCalculator()
    rs_c = RelativeStrengthIndexCalculator()


    def consume(self, ticker: str, dataframe: pd.DataFrame, window_size: int) -> None:

        # Pass ticker and dataframe to base class via method
        # and not constructor to avoid redeclaring classes
        # on processing of each slice and cluttering the heap
        BaseStrategy.ticker = ticker
        BaseStrategy.dataframe = dataframe

        # Prepare dataframe for processing
        self.prepare_dataframe()

        # Provide dataframe and window size to calculators
        self.kr_c.dataframe = dataframe
        self.kr_c.window_size = window_size

        self.sw_c.dataframe = dataframe
        self.sw_c.window_size = window_size

        self.pc_c.dataframe = dataframe
        self.pc_c.window_size = window_size

        self.at_c.dataframe = dataframe
        self.at_c.window_size = window_size

        self.dm_c.dataframe = dataframe
        self.dm_c.window_size = window_size

        self.rs_c.dataframe = dataframe
        self.rs_c.window_size = window_size


    def calculate(self) -> None:

        self.sw_c.calculate_swings()
        self.kr_c.calculate_key_reversals()
        self.pc_c.calculate_price_channels()
        self.rs_c.calculate_relative_strength_index()
        self.at_c.calculate_average_true_range(preserve_tr=True)
        self.dm_c.calculate_moving_dist_moments(mean=True, std=True, skew=True, kurt=True, z_score=True)


    def mark_signals(self) -> None:

        # Loop through frame
        for i, (label, row) in enumerate(self.dataframe.iterrows()):

            # Combine indicators
            indicators_meet = self.__comb_indicators(row)

            if indicators_meet:

                self.dataframe.loc[label, 'action'] = 1.0


    def clean(self) -> None:

        # Remove NaN values from the dataframe
        self.dataframe.dropna(inplace=True)


    def __comb_indicators(self, row: pd.Series) -> bool:

        # Current price is below or equal lower bound of price channel:
        # potential for reversal
        below_lower_bound = row['close'] <= row['l_bound']

        # Relative Strength Index is oversold:
        # potential for recovery
        rsi_oversold = row['rsi'] < 40

        # Up swing bar has taken place:
        # potential for continuation
        up_swing = row['sw'] == 1.0

        # Key Reversal bar has taken place:
        # potential for reversal
        key_reversal = row['kr'] == 1

        # Current price is within lower part of the channel:
        # potential for reversal
        within_lower_channel = (
            abs(row['close'] - row['l_bound']) < abs(row['close'] - row['lbf'])
        )

        # Moving Kurtosis is positive:
        # price is peaking
        mov_kurt_is_positive = row['kurt'] >= 3.0

        # Moving Skewness is positive:
        # price is within lower half of distribution
        mov_skew_is_positive = row['skew'] > 0

        # Grab z-score to filter against
        z_score = abs(row['z_score'])

        # Current price movement is equal or above 2 standard deviations:
        # price movement is an outlier
        twice_std = z_score >= 2.0

        # Current price movement is equal or above 3 standard deviations:
        # price movement is an outlier
        thrice_std = z_score >= 3.0

        # Slope of price channel is positive:
        # price is on recovery
        slope_is_positive = row['slope'] > row['prev_slope']

        # Volatility is twice above average:
        # directional moves are reinforced
        vol_above_norm = row['tr'] > row['atr'] * 2

        indicators_meet = (
            below_lower_bound
        )  or (
            rsi_oversold
        ) or (
            key_reversal and
            thrice_std
        ) or (
            up_swing and
            within_lower_channel
        ) or (
            within_lower_channel and
            slope_is_positive and
            twice_std
        ) or (
            mov_kurt_is_positive and
            mov_skew_is_positive and
            slope_is_positive and
            vol_above_norm
        )

        return indicators_meet