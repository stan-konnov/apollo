import pandas as pd

from plutus.code.strategies.base import BaseStrategy

from plutus.code.calc.dmv2 import DistributionMomentsCalculator
from plutus.code.calc.atr import AverageTrueRangeCalculator


class SkewnessKurtosisVolatility(BaseStrategy):

    # Calculators used
    dm_c = DistributionMomentsCalculator()
    at_c = AverageTrueRangeCalculator()


    def consume(self, ticker: str, dataframe: pd.DataFrame, window_size: int) -> None:

        # Pass ticker and dataframe to base class via method
        # and not constructor to avoid redeclaring classes
        # on processing of each slice and cluttering the heap
        BaseStrategy.ticker = ticker
        BaseStrategy.dataframe = dataframe

        # Prepare dataframe for processing
        self.prepare_dataframe()

        # Provide dataframe and window size to calculators
        self.dm_c.dataframe = dataframe
        self.at_c.dataframe = dataframe

        self.dm_c.window_size = window_size
        self.at_c.window_size = window_size


    def calculate(self) -> None:

        # Calculate values necessary for given strategy
        self.dm_c.calculate_moving_dist_moments(mean=False, std=False, skew=True, kurt=True)
        self.at_c.calculate_average_true_range()


    def mark_signals(self) -> None:

        # Calculate ATR mean
        atr_mean = self.dataframe['atr'].mean()

        # Loop through frame
        for _, (label, row) in enumerate(self.dataframe.iterrows()):

            # Combine indicators
            indicators_meet = self.__comb_indicators(row, atr_mean)

            if indicators_meet:

                self.dataframe.loc[label, 'action'] = 1.0


    def clean(self) -> None:

        # Remove NaN values from the dataframe
        self.dataframe.dropna(inplace=True)


    def __comb_indicators(self, row: pd.Series, atr_mean: float) -> bool:

        # Moving Kurtosis is negative:
        # price is flattening
        mov_kurt_is_negative = row['kurt'] < 0

        # Moving Skewness is positive:
        # price is within lower half of distribution
        mov_skew_is_positive = row['skew'] > 0

        # ATR (volatility) is below average:
        # potential for breakout
        vol_below_avg = row['atr'] < atr_mean

        # Combine indicators
        indicators_meet = (
            mov_kurt_is_negative and
            mov_skew_is_positive and
            vol_below_avg
        )

        return indicators_meet