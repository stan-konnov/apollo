import numpy as np

from pandas.core.frame import DataFrame


class MarkovChainsCalculator:

    dataframe: DataFrame = None

    # Threshold of significance of absolute percentage change over prices
    tos: float = 0.0

    # Initial Probability Matrix
    tm: DataFrame = None

    # Eqalibrium Matrix where probabilites do not change further with t+n
    em: DataFrame = None


    def compute_markov_chains(self) -> None:

        # Calculate percentage change between closes
        self.dataframe['change'] = self.dataframe['close'].pct_change()

        # Deduce threshold of significance
        self.__deduce_tos()

        # Mark state of each row
        self.__mark_states()

        # Build transition matrix
        self.__build_trans_matrix()

        # Find eqalibrium matrix
        self.__find_eqalib_matrix()

        # Mark probabilities into frame
        self.dataframe['u_prob'] = self.em.loc[self.em.index[0]]['up']
        self.dataframe['d_prob'] = self.em.loc[self.em.index[0]]['down']
        self.dataframe['f_prob'] = self.em.loc[self.em.index[0]]['flat']

        # Drop columns relevant only to this module
        self.dataframe.drop(columns=['change', 'state', 'prior_state'], inplace=True)


    def __deduce_tos(self) -> None:

        # Get absolute changes
        abs_change = abs(self.dataframe['change'])

        # We use IQR method (Tukey's rule) to identify outliers amongst absolute values of changes
        # We assume non-normal (skewed) distribution
        # which "is common for most price data", Kaufman, TSM, 2020, p. 37

        # Get first and third quartiles of absolute changes
        q1 = abs_change.quantile(0.25)
        q3 = abs_change.quantile(0.75)

        # Calculate Inter Quartile Range
        iqr = q3 - q1

        # Calculate lower bound of outliers within absolute changes
        # Mind, if IQR method produces negative value, there are no outliers
        # In such case, we take 0.0 as our lower bound
        self.tos = max(0.0, q1 - 1.5 * iqr)

        # Arbirtrary way is to take lower N% from absolute changes
        # self.tos = abs_change.quantile(0.2)


    def __mark_states(self) -> None:

        # Declare state column
        self.dataframe['state'] = ''

        # Loop through frame and deduce states of each row based on percentage change
        for _, (label, row) in enumerate(self.dataframe.iterrows()):

            change = row['change']

            # If absolute change does not fall within TOS or it's a first row, mark it as flat
            if abs(change) <= self.tos or np.isnan(change):

                self.dataframe.loc[label, 'state'] = 'flat'

            # If otherwise positive change, mark it as up
            elif change > 0.0:

                self.dataframe.loc[label, 'state'] = 'up'

            # If otherwise negative change, mark it as down
            elif change < 0.0:

                self.dataframe.loc[label, 'state'] = 'down'

        # Mark previous state of each row
        self.dataframe['prior_state'] = self.dataframe['state'].shift(1)


    def __build_trans_matrix(self) -> None:

        # Grab previously marked states
        states = self.dataframe[['prior_state', 'state']].dropna()

        # Build frequency distribution matrix off them
        freq_dist_matrix = states.groupby(['prior_state', 'state']).size().unstack().fillna(0)

        # Build transition matrix, a.k.a. Initial Probability Matrix
        self.tm = freq_dist_matrix.apply(lambda x: x / float(x.sum()), axis=1)


    def __find_eqalib_matrix(self) -> None:

        # From the first transition matrix, t0, we can make t+n forecasts

        # Transition matrices in Markov Chains change
        # with every next forecast until so-called
        # Eqalibrium Matrix (Stationary Distribution) is reached
        # It represents the probability of each data point being in each state:

        # P(state)i+1 = P(state)i, Kaufman, TSM, p. 54

        # To produce Eqalibrium Matrix, we multiply each
        # subsequent transition matrix on original matrix,
        # until probabilites stay the same

        # Previous matrix to compare multiplied matrix with
        prev_trans_matrix = self.tm.copy()

        # Current multiplied matrix
        curr_trans_matrix = self.tm.dot(self.tm)

        # Number of potential iterations
        n = 1

        # While previous multiplied matrix does not equal current multiplied matrix
        while not prev_trans_matrix.equals(curr_trans_matrix):

            # Set previous matrix to current matrix
            prev_trans_matrix = curr_trans_matrix.copy()

            # Multiply current matrix by original matrix
            #
            # Note, we do not use .dot() as it, apparently, confuses
            # pandas due to float precision issues in python
            # In such, we use numpy and bring
            # original matrix to the power of incremented n until eqalibrium
            curr_trans_matrix = DataFrame(
                np.linalg.matrix_power(self.tm, n + 1)
            )

            n += 1

        # Set indices and columns
        curr_trans_matrix.index = self.tm.index
        curr_trans_matrix.columns = self.tm.columns

        self.em = curr_trans_matrix