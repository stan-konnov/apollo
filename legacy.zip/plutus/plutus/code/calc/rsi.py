from pandas.core.series import Series
from pandas.core.frame import DataFrame


class RelativeStrengthIndexCalculator:

    dataframe: DataFrame = None

    # An interval for the moving average calculation
    interval: int = 14


    def calculate_rsi(self) -> None:

        # Identify deltas between close prices
        close_delta = self.dataframe['close'].diff()

        # Break deltas into positive and negative
        pos_delta = close_delta.clip(lower=0)
        neg_delta = close_delta.clip(upper=0) * -1

        # Calculate moving averages
        # for positive and negative deltas
        pos_dlt_ma = self.__calc_ma(pos_delta)
        neg_dlt_ma = self.__calc_ma(neg_delta)

        # Divide positive ma by negative
        # to get to the Relative Strength
        rel_str = pos_dlt_ma / neg_dlt_ma

        # Calculate Relative Strength Index
        rsi = 100 - (100 / (1 + rel_str))

        # Write to the dataframe
        self.dataframe['rsi'] = rsi


    def __calc_ma(self, series: Series) -> Series:

        # NOTE: @Stan, please change me to J. Welles Wilder's EMA (The creator of ATR):
        # ewm(alpha = 1 / window_size, min_periods = window_size, adjust = False).mean()

        # Calculate exponential moving average
        # over provided series using interval
        ma = series.ewm(com=self.interval - 1, adjust=True, min_periods=self.interval).mean()

        return ma

