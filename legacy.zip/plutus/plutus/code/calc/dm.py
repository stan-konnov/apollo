from pandas.core.frame import DataFrame


class DistributionMomentsCalculator:

    dataframe: DataFrame = None

    # Smoothing level to use with prices
    price_alpha: float = 0.10

    # Smoothing level to use with standard deviation
    std_alpha: float = 0.05

    # Smoothing level to use with skewness
    skew_alpha: float = 0.333


    def calculate_moving_dist_moments(self) -> None:

        # As per Kaufman, first step is to perform double smoothing
        # via applying simple exponential smoothing twice
        # where first run goes over raw data points
        # and second over smoothed values yielded by first

        prices = list(self.dataframe['close'])

        s_prices, ds_prices = self.__double_smooth_prices(prices)

        # Then, calculate moving mean between
        # sinlge smoothed and double smoothed prices

        moving_mean = self.__calc_moving_mean(self.price_alpha, s_prices, ds_prices)

        #    ####    #

        # Second step, is to calculate moving deviation
        # between closing prices and moving mean

        moving_deviation = self.__calc_moving_deviation(prices, moving_mean)

        #    ####    #

        # Third step is to double smooth moving deviation
        # by once again applying simple exponential smoothing

        s_deviation, ds_deviation = self.__double_smooth_deviation(moving_deviation)

        # Then, calculate moving mean between
        # sinlge smoothed and double smoothed deviation

        dev_moving_mean = self.__calc_moving_mean(self.std_alpha, s_deviation, ds_deviation)

        # Final part of third step, is to calculate
        # moving standard deviation of moving deviation

        moving_std = self.__calc_moving_std(dev_moving_mean)

        #    ####    #

        # Last, forth step is to calculate
        # moving skewness using double smoothed prices
        # moving mean and moving deviation

        # Does not follow Kaufman's original implementation
        # check comments for self.__calc_ew_moving_skew()

        moving_skew = self.__calc_moving_skew(ds_prices, moving_mean, moving_std)

        #    ####    #

        # Expand with moving kurtosis
        self.__calc_moving_kurt()

        # Write to the dataframe
        self.dataframe['mov_avg'] = 0.0
        self.dataframe['mov_std'] = 0.0
        self.dataframe['mov_skew'] = 0.0

        for i, (label, _) in enumerate(self.dataframe.iterrows()):

            self.dataframe.loc[label, 'mov_avg'] = moving_mean[i]
            self.dataframe.loc[label, 'mov_std'] = moving_std[i]
            self.dataframe.loc[label, 'mov_skew'] = moving_skew[i]


    def __double_smooth_prices(self, prices: list[float]) -> tuple[list[float], list[float]]:

        # We start with first observation
        s_prices = [prices[0]]

        # Run through prices, starting from the second entry
        for i in range(1, len(prices)):

            # Calculate Simple Exponential Smoothing: a * Pi + (1 - a) * Pi-1
            s_price = self.price_alpha * prices[i] + (1 - self.price_alpha) * s_prices[i - 1]

            # Append smoothed price to the list
            s_prices.append(s_price)

        # We once again start with the first observation
        ds_prices = [s_prices[0]]

        # Run through smoothed prices, starting from the second entry
        for i in range(1, len(s_prices)):

            # Calculate SES again: a * Si + (1 - a) * Di-1
            ds_price = self.price_alpha * s_prices[i] + (1 - self.price_alpha) * ds_prices[i - 1]

            # Append double smoothed price to the list
            ds_prices.append(ds_price)

        return (s_prices, ds_prices)


    def __calc_moving_mean(self, alpha: float, s_dps: list[float], ds_dps: list[float]) -> list[float]:

        # We also reuse this method for
        # calculating moving mean of deviation
        # Therefore, alpha and data are parametrized

        moving_mean = []

        # Run through both sets of smoothed data points
        for i in range(0, len(s_dps)):

            # Calcualate Moving Mean: ((2 - a) * Si - Di) / (1 - a)
            mean = ((2 - alpha)  * s_dps[i] - ds_dps[i]) / (1 - alpha)

            # Append calcualated mean to the list of means
            moving_mean.append(mean)

        return moving_mean


    def __calc_moving_deviation(self, prices: list[float], moving_mean: list[float]) -> list[float]:

        moving_deviation = []

        # Run through prices and means
        for i in range(0, len(prices)):

            # Calculate Deviation, which is a simple diff
            deviation = prices[i] - moving_mean[i]

            # Append diff to the list of moving deviations
            moving_deviation.append(deviation)

        return moving_deviation


    def __double_smooth_deviation(self, moving_deviation: list[float]) -> tuple[list[float], list[float]]:

        # We start with first observation
        s_deviation = [moving_deviation[0]]

        # Run through deviations, starting from the second entry
        for i in range(1, len(moving_deviation)):

            # Calculate SES; mind, here we are
            # using absolute value of moving deviation
            deviation = self.std_alpha * abs(moving_deviation[i]) + (1 - self.std_alpha) * s_deviation[i - 1]

            # Append smoothed deviation to the list
            s_deviation.append(deviation)

        # We start with first observation
        ds_deviation = [s_deviation[0]]

        # Run through smoothed deviations, starting from the second entry
        for i in range(1, len(s_deviation)):

            # Calculate SES
            deviation = self.std_alpha * s_deviation[i] + (1 - self.std_alpha) * ds_deviation[i - 1]

            # Append double smoothed deviation to the list
            ds_deviation.append(deviation)

        return (s_deviation, ds_deviation)


    def __calc_moving_std(self, dev_moving_mean: list[float]) -> list[float]:

        moving_std = []

        # Run through means of deviations
        for i in range(0, len(dev_moving_mean)):

            # Note, here we take z score of 1.25, one unit of standard deviation
            std = 1.25 * dev_moving_mean[i]

            # Append moving standard deviation to the list
            moving_std.append(std)

        return moving_std


    def __calc_moving_skew(self, ds_prices: list[float], mov_mean: list[float], mov_std: list[float]) -> list[float]:

        # Classical Fisher-Pearson (coefficient of skewness)

        # We don't need to start with first observation
        # as we don't apply exponential smoothing
        mov_skew = []

        # Number of observations
        N = len(ds_prices)

        # Run through double smoothed prices
        for i in range(0, N):

            # Default 0-ed value
            skew = 0.0

            # Calculate numerator: (Pi - Mi)^3 / N
            n = pow(ds_prices[i] - mov_mean[i], 3) / N

            # Calculate denominator: STDi^3
            d = pow(mov_std[i], 3)

            # Check if both operands are valid
            if n > 0 and d > 0:

                # Divide if check passed
                skew = n / d

            # If negative skewness (prices moving up)
            if skew < 0.0:

                # Mark it as 0, since we only care about entry points at the lows
                skew = 0.0

            # Append moving skewness to the list
            mov_skew.append(skew)

        return mov_skew


    def __calc_ew_moving_skew(self, mov_dev: list[float], mov_std: list[float]) -> list[float]:

        # Adapted from Kaufman, but is not applicable to daily data
        # due to exponential smoothing
        # In such, used only for analysis of yearly data

        # We start with first observation
        mov_skew = [mov_dev[0]]

        # Run through moving deviations, starting from the second entry
        for i in range(1, len(mov_dev)):

            # Default 0-ed value
            skew = 0.0

            # Calculate numerator: (a * DEVi^3 + (1 - a) * DEVi-1)
            n = (self.skew_alpha * pow(mov_dev[i], 3) + (1 - self.skew_alpha) * mov_skew[i - 1])

            # Calculate denominator: STDi^3
            d = pow(mov_std[i], 3)

            # Normalization check (TSM Moving Skewness additional materials)
            if n > 0.1 and d > 0.1:

                # Divide if check passed
                skew = n / d

            # Append moving skewness to the list
            mov_skew.append(skew)

        return mov_skew


    def __calc_moving_kurt(self) -> None:

        # Calculate moving kurtosis with the window suggested by Kaufman
        # and ignore values that are below the threshold of excess kurtosis (3)
        self.dataframe['mov_kurt'] = self.dataframe['close'].rolling(window=20).kurt().apply(
            lambda x: x if x > 3 else 0
        )