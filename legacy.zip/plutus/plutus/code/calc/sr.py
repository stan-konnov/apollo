import numpy as np

from sklearn.cluster import KMeans
from pandas.core.frame import DataFrame

class SupportAndResistanceCalculator:

    dataframe: DataFrame = None

    # Number of clusters to break down close prices into
    n_clusters: int = 6

    # K-means is not a deterministic algorithm
    # It usually starts with some randomized initialization procedure,
    # and this randomness means that different runs will start at different points

    # Seeding the pseudo-random number generator ensures
    # that this randomness will always be the same for identical seeds
    kmeans_seed: int = 3425

    # Margin of acceptance within which price action has to fall to deem
    # support or resistance level as strong
    strength_margin: int = 0.04


    def __init__(self) -> None:

        # Prices to use throughout the execution
        self.prices: list[int] = []

        # Prices assigned to their respective clusters
        self.clusters: list[int] = []

        # Min max values of each cluster
        self.min_max: list[list[int]] = []

        # Average values of each cluster
        self.cluster_avgs: list[list[int]] = []


    def calculate_sr_levels(self) -> None:

        self.__perform_cluster_analysis()
        self.__break_down_by_min_max()
        self.__average_within_clusters()
        self.__remove_extrema()
        self.__group_price_to_avgs()
        self.__mark_levels_to_dataframe()
        self.__cleanup_before_next_run()


    def __perform_cluster_analysis(self) -> None:

        self.prices = np.array(self.dataframe['close'])

        # n_init in v1.2? defaults to 10.  It defaults to 'auto' starting in v1.4
        # Setting n_init to 10 manually here to preserve the current behavior and
        # also to supress the related warning
        kmeans = KMeans(n_clusters=self.n_clusters, random_state=self.kmeans_seed, n_init=10).fit(self.prices.reshape(-1, 1))

        # Assign every price with a cluster
        self.clusters = kmeans.predict(self.prices.reshape(-1, 1))


    def __break_down_by_min_max(self) -> None:

        # init for each cluster group
        for i in range(self.n_clusters):

            # Add values for which no price could be greater or less
            self.min_max.append([np.inf, -np.inf])

        # Get min/max for each cluster
        for i in range(len(self.prices)):

            # Get cluster assigned to price
            cluster = self.clusters[i]

            # Compare for min value
            if self.prices[i] < self.min_max[cluster][0]:

                self.min_max[cluster][0] = self.prices[i]

            # Compare for max value
            if self.prices[i] > self.min_max[cluster][1]:

                self.min_max[cluster][1] = self.prices[i]


    def __average_within_clusters(self) -> None:

        # Sort based on cluster minimum
        s = sorted(self.min_max, key=lambda x: x[0])

        # For each cluster get average of
        for i, (_min, _max) in enumerate(s):

            self.cluster_avgs.append([i, (_max + _min) / 2])


    # Not used, kept as per original implementation
    def __average_accross_clusters(self) -> None:

        # Sort based on cluster minimum
        s = sorted(self.min_max, key=lambda x: x[0])

        # For each cluster get average of
        for i, (_min, _max) in enumerate(s):

            # Append min from first cluster
            if i == 0:
                self.cluster_avgs.append([i, _min])

            # Append max from last cluster
            if i == len(self.min_max) - 1:

                self.cluster_avgs.append([i, _max])

            # Append average from cluster and adjacent for all others
            else:
                self.cluster_avgs.append([i, sum([_max, s[i + 1][0]]) / 2])


    def __remove_extrema(self) -> None:

        # Pool all the averages together
        pool = [cluster_avg[1] for cluster_avg in self.cluster_avgs]

        _min = min(pool)

        _max = max(pool)

        # Remove min and max from them
        self.cluster_avgs = list(
            filter(lambda cluster_avg: cluster_avg[1] != _min and cluster_avg[1] != _max, self.cluster_avgs)
        )


    def __group_price_to_avgs(self) -> None:

        grouped_prices = {}

        # Get cluster indices
        relevant_clusters = [cluster[0] for cluster in self.cluster_avgs]

        # Init groups for every cluster
        for cluster in relevant_clusters:

            grouped_prices[cluster] = []

        # Group price values by clusters
        for i in range(len(self.prices)):

            cluster = self.clusters[i]

            # Skip price if it falls into extrema cluster
            if cluster not in relevant_clusters:

                continue

            grouped_prices[cluster].append(self.prices[i])

        # Find prices within each group around it's cluster average
        for cluster, price_group in grouped_prices.items():

            # Get cluster average for the group
            cluster_avg = self.cluster_avgs[cluster - 1][1]

            # Define margin of +/- N% around cluster average
            acceptance_margin = cluster_avg * self.strength_margin

            # Map price group to numpy array
            price_group_arr = np.array(price_group)

            # Locate prices with closest proximity to cluster average
            accepted_prices_idx = (np.abs(price_group_arr - acceptance_margin)).argmin()

            # Determine cluster strength
            cluster_strength = accepted_prices_idx

            # Add strength to the cluster
            self.cluster_avgs[cluster - 1].append(cluster_strength)

        # Get average cluster strength
        avg_cluster_strength = sum([cluster[2] for cluster in self.cluster_avgs]) / len(self.cluster_avgs)

        # Get clusters whose strength exceeds the average
        self.cluster_avgs = list(
            filter(lambda cluster_avg: cluster_avg[2] >= avg_cluster_strength, self.cluster_avgs)
        )


    def __mark_levels_to_dataframe(self) -> None:

        # Loop through indentified sr levels and write them into the dataframe
        for i, cluster_avg in enumerate(self.cluster_avgs):

            self.dataframe[f"sr_level_{i + 1}"] = cluster_avg[1]


    def __cleanup_before_next_run(self) -> None:

        # Cleanup all used data stuctures
        # as the values creep into the execution of next time series
        self.prices = []
        self.clusters = []
        self.min_max = []
        self.cluster_avgs = []