import pandas as pd


class AverageTrueRangeCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None


    def calculate_average_true_range(self, preserve_tr: bool = False) -> None:

        # Calculate rolling True Range
        self.dataframe['tr'] = self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_tr, args=(self.dataframe, )
        )

        # Calculate Average True Range using J. Welles Wilder's EMA (The creator of ATR)
        self.dataframe['atr'] = self.dataframe['tr'].ewm(
            alpha = 1 / self.window_size, min_periods = self.window_size, adjust = False
        ).mean()

        # If caller requires True Range, return
        if preserve_tr:

            return

        # Otherwise, drop the column
        self.dataframe.drop('tr', axis=1, inplace=True)


    def __calc_tr(self, series: pd.Series, dataframe: pd.DataFrame) -> None:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Get high, low, and previous close
        high = rolling_df['high']
        low = rolling_df['low']
        prev_close = rolling_df['close'].shift()

        # Calculate True Range for each row, where TR is:
        # max(Ht - Lt, Ht - Ct-1, Ct-1 - Lt)
        # Kaufman, Trading Systems and Methods, 2020, p.850
        true_range = [high - low, high - prev_close, prev_close - low]

        # Bring to absolute values
        true_range = [tr.abs() for tr in true_range]

        # Get the max out of 3 operations
        true_range = pd.concat(true_range, axis=1).max(axis=1)

        # Return latest entry from processed window
        return true_range.iloc[-1]