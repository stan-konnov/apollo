import pandas as pd


class RelativeStrengthIndexCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None


    def calculate_relative_strength_index(self) -> None:

        # Calculate positive deltas
        self.dataframe['pos_delta'] = self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_delta, args=(self.dataframe, 'positive')
        )

        # Calculate negative deltas
        self.dataframe['neg_delta'] = self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_delta, args=(self.dataframe, 'negative')
        )

        # Calculate EMA for both deltas
        self.dataframe['pos_delta_ma'] = self.__calc_ema(self.dataframe['pos_delta'])
        self.dataframe['neg_delta_ma'] = self.__calc_ema(self.dataframe['neg_delta'])

        # Calculate RSI
        self.dataframe['rsi'] = self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_rsi, args=(self.dataframe, )
        )

        # Drop delta columns
        self.dataframe.drop(
            columns=['pos_delta', 'neg_delta', 'pos_delta_ma', 'neg_delta_ma'],
            inplace=True
        )

    def __calc_delta(self, series: pd.Series, dataframe: pd.DataFrame, d_type: str) -> None:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Identify deltas between close prices
        close_delta = rolling_df['close'].diff()

        # Calculate either positive or negative
        if d_type == 'positive':

            delta = close_delta.clip(lower=0)

        else:

            delta = close_delta.clip(upper=0) * -1

        # Return latest entry from processed window
        return delta.iloc[-1]


    def __calc_ema(self, series: pd.Series) -> pd.Series:

        # Calculate EMA using J. Welles Wilder's EMA (The creator of RSI)
        ema = series.ewm(
            alpha = 1 / self.window_size, min_periods = self.window_size, adjust = False
        ).mean()

        return ema


    def __calc_rsi(self, series: pd.Series, dataframe: pd.DataFrame) -> None:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Calculate Relative Strength
        rel_str = rolling_df['pos_delta_ma'] / rolling_df['neg_delta_ma']

        # Calculate Relative Strength Index
        rsi = 100 - (100 / (1 + rel_str))

        # Return latest entry from processed window
        return rsi.iloc[-1]
