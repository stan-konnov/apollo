import pandas as pd
import numpy as np


class SwingsCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None

    in_downswing = False

    swing_filter: float = 0.005

    swing_low: float = None

    swing_high: float = None

    swings: list[float] = None


    def calculate_swings(self) -> None:

        # Reset indices to allow for slicing operations
        self.dataframe.reset_index(inplace=True)

        # Record the low of the first bar as the swing low
        self.swing_low = self.dataframe.iloc[self.window_size - 2]['low']

        # Record the high of the first bar as swing high
        self.swing_high = self.dataframe.iloc[self.window_size - 2]['high']

        # Following the swing high, assume we are in downswing
        # Kaufman, TSM, p. 168
        self.in_downswing = True

        # Fill swings array with N NaN, where N = window size
        self.swings = np.full((1, self.window_size - 1), np.nan).flatten().tolist()

        # Calculate swings
        self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_sw, args=(self.dataframe, )
        )

        # Write swings to the dataframe
        self.dataframe['sw'] = self.swings

        # Reset indices back to avoid discrepancies
        self.dataframe.set_index('index', inplace=True)

    def __calc_sw(self, series: pd.Series, dataframe: pd.DataFrame) -> None:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Grab current low
        current_low = rolling_df.iloc[-1]['low']

        # Grab current high
        current_high = rolling_df.iloc[-1]['high']

        # Calculate current swing filter
        current_swing_filter = rolling_df.iloc[-1]['close'] * self.swing_filter

        # If we are in downswing
        if self.in_downswing == True:

            # Test if downswing continues
            if current_low < self.swing_low:

                # Treat current low as new swing low
                self.swing_low = current_low

            # Test if downswing reverses
            if current_high - self.swing_low > current_swing_filter:

                # If so, we have an upswing
                self.in_downswing = False

                # Treat current low as new swing low
                self.swing_low = current_low

                # Treat current high as new swing high
                self.swing_high = current_high

                # Add positive float to the list
                self.swings.append(1.0)

                # Return dummy float
                return 0.0

            # Append falsy float as it is a continuation
            self.swings.append(0.0)

            # Return dummy float
            return 0.0

        # If we are in upswing
        else:

            # Test if upswing continues
            if current_high > self.swing_high:

                # Treat current high as new swing high
                self.swing_high = current_high

            # Test if upswing reverses
            if self.swing_high - current_low > current_swing_filter:

                # If so, we have downswing
                self.in_downswing = True

                # Append negative float to the list
                self.swings.append(-1.0)

                # Return dummy float
                return 0.0

            # Append falsy float as it is a continuation
            self.swings.append(0.0)

            # Return dummy float
            return 0.0
