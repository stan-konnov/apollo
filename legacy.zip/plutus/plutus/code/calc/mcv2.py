import pandas as pd
import numpy as np


class MarkovChainsCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None

    u_prob: list[float] = None
    d_prob: list[float] = None
    f_prob: list[float] = None


    def calculate_markov_chains(self) -> None:

        # Fill probabilites arrays with N NaN, where N = window size
        self.u_prob = np.full((1, self.window_size - 1), np.nan).flatten().tolist()
        self.d_prob = np.full((1, self.window_size - 1), np.nan).flatten().tolist()
        self.f_prob = np.full((1, self.window_size - 1), np.nan).flatten().tolist()

        # Calculate probabilites via Markov Chains
        self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_mc, args=(self.dataframe, )
        )

        # Write probabilities to dataframe
        self.dataframe['u_prob'] = self.u_prob
        self.dataframe['d_prob'] = self.d_prob
        self.dataframe['f_prob'] = self.f_prob


    def __calc_mc(self, series: pd.Series, dataframe: pd.DataFrame) -> float:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Calculate percentage change between closes
        rolling_df['change'] = rolling_df['close'].pct_change()

        # Get absolute changes
        abs_change = abs(rolling_df['change'])

        # We take lower 5% from absolute changes as our threshold
        # (classical statistical significance)
        tos = abs_change.quantile(0.05)

        # Define conditions for 3-state regime (up, down, flat)
        conditions = [
            ((rolling_df['change'] > 0.0) & (abs_change > tos)),
            ((rolling_df['change'] < 0.0) & (abs_change > tos)),
            ((abs_change <= tos) | (np.isnan(abs_change)))
        ]

        # Define labels for regimes
        choices = ['up', 'down', 'flat']

        # Mark states
        rolling_df['state'] = np.select(conditions, choices)

        # Mark previous states
        rolling_df['prior_state'] = rolling_df['state'].shift(1)

        # Grab previously marked states
        states = rolling_df[['prior_state', 'state']].dropna()

        # Build frequency distribution matrix off them
        fd_matrix = states.groupby(['prior_state', 'state']).size().unstack().fillna(0)

        # Build transition matrix, a.k.a. Initial Probability Matrix
        tr_matrix = fd_matrix.apply(lambda x: x / float(x.sum()), axis=1)

        # From the first transition matrix, t0, we can make t+n forecasts

        # Transition matrices in Markov Chains change
        # with every next forecast until so-called
        # Eqalibrium Matrix (Stationary Distribution) is reached
        # It represents the probability of each data point being in each state:

        # P(state)i+1 = P(state)i, Kaufman, TSM, p. 54

        # To produce Eqalibrium Matrix, we multiply each
        # subsequent transition matrix on original matrix,
        # until probabilites stay the same

        # Previous matrix to compare multiplied matrix with
        prev_trans_matrix = tr_matrix.copy()

        # Current multiplied matrix
        curr_trans_matrix = tr_matrix.dot(tr_matrix)

        # Number of potential iterations
        # We take maximum of 10, since we observed
        # that proabilites stop changing after 10 mutliplications
        n = 1

        # While previous multiplied matrix does not equal current multiplied matrix
        while not prev_trans_matrix.equals(curr_trans_matrix) and n != 10:

            # Set previous matrix to current matrix
            prev_trans_matrix = curr_trans_matrix.copy()

            # Multiply current matrix by original matrix
            #
            # Note, we do not use .dot() as it, apparently, confuses
            # pandas due to float precision issues in python
            # In such, we use numpy and bring
            # original matrix to the power of incremented n until eqalibrium
            curr_trans_matrix = pd.DataFrame(
                np.linalg.matrix_power(tr_matrix, n + 1)
            )

            n += 1

        # Set indices and columns
        curr_trans_matrix.index = tr_matrix.index
        curr_trans_matrix.columns = tr_matrix.columns

        eq_matrix = curr_trans_matrix

        # Preserve probabilites
        self.u_prob.append(eq_matrix.loc[eq_matrix.index[0]]['up'])
        self.d_prob.append(eq_matrix.loc[eq_matrix.index[0]]['down'])
        self.f_prob.append(eq_matrix.loc[eq_matrix.index[0]]['flat'])

        # Return dummy float
        return 0.0