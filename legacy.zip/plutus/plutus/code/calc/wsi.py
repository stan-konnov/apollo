import pandas as pd
import numpy as np


class WildersSwingIndexCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None

    limit_move: int = 100

    swing_points: list[float] = None


    def calculate_swing_index(self) -> None:

        # Fill swing points array with N NaN, where N = window size
        # NOTE: we fill up to and not including last index, since capturing
        # SP involves comparing middle value with previous and following bar
        self.swing_points = np.full((1, self.window_size - 2), np.nan).flatten().tolist()

        # Calculate rolling Swing Index
        self.dataframe['si'] = self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_si, args=(self.dataframe, )
        )

        # Calculate rolling Accumulated Swing Index
        self.dataframe['asi'] = self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_asi, args=(self.dataframe, )
        )

        # Calculate rolling Swing Points
        self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_sp, args=(self.dataframe, )
        )

        # Mark latest SP entry as falsy, since we don't have foresight
        # to decide if the latest bar is higher/lower than the one after it
        self.swing_points.append(0.0)

        # Mark Swing Points into the dataframe
        self.dataframe['sp'] = self.swing_points

        # Drop SI column since we don't need it
        self.dataframe.drop(columns=['si'], inplace=True)


    def __calc_si(self, series: pd.Series, dataframe: pd.DataFrame) -> float:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Get open, high, low, close
        open = rolling_df['open']
        high = rolling_df['high']
        low = rolling_df['low']
        close = rolling_df['close']

        # Shift to get previous open and previous close
        prev_open = rolling_df['open'].shift()
        prev_close = rolling_df['close'].shift()

        # Calculate diffs between:
        # (Ht - Ct-1, Lt - Ct-1, Ht - Lt)
        # Kaufman, Trading Systems and Methods, 2020, p.174
        diffs = [high - prev_close, low - prev_close, high - low]

        # Bring to list of absolute floats
        abs_diffs = [abs(d.iloc[-1]) for d in diffs]

        # Get the highest value
        highest_value = max(abs_diffs)

        # Determine the index of the highest value
        # To decide which TR calculation we will be using
        highest_value_index = abs_diffs.index(highest_value)

        # Calculate K, the highest value of first two diffs
        highest_diff = max(abs_diffs[:-1])

        # Calculate TR using one of the methods based on highest value index
        true_range = self.__calc_tr(highest_value_index, high, low, prev_close, prev_open)

        # Finally, calculate Swing Index:
        # K = highest of first two diffs, M = limit move
        # SI = 50 * ( ( (Ct - Ct-1) + 0.50(Ct - Ot) + 0.25(Ct-1 - Ot-1) ) / TRt ) * (K / M)

        # Calculate numerator first
        numerator = (
            (close - prev_close) + (0.50 * (close - open)) + (0.25 * (prev_close - prev_open))
        )

        # Then calculate the actual index
        swing_index = 50 * (numerator / true_range) * (highest_diff / self.limit_move)

        # Return latest entry from processed window
        return swing_index.iloc[-1]


    def __calc_asi(self, series: pd.Series, dataframe: pd.DataFrame) -> float:

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Calculate ASI
        accumulated_swing_index = rolling_df['si'].sum()

        # Return value from processed window
        return accumulated_swing_index


    def __calc_sp(self, series: pd.Series, dataframe: pd.DataFrame) -> float:

        # High/Low Swing Point:
        # Any day on which the ASI is higher/lower
        # than both the previous and the following day
        # Kaufman, Trading Systems and Methods, 2020, p.175

        # Slice out a chunk of dataframe to work with
        rolling_df = dataframe.loc[series.index]

        # Get the last 3 ASI entries
        last_three_asi = rolling_df.iloc[self.window_size - 3 :]['asi']

        # Bring to list of floats
        last_three_asi = [asi for asi in last_three_asi]

        # Unpack ASI values
        prev, curr, next = last_three_asi

        # If current ASI is higher than previous and next (HSP)
        if curr > prev and curr > next:

            # Append positive float to the list
            self.swing_points.append(1.0)

        # If current ASI is lower than previous and next (LSP)
        elif curr < prev and curr < next:

            # Append negative float to the list
            self.swing_points.append(-1.0)

        else:

            # Otherwise, append falsy float
            self.swing_points.append(0.0)

        # Return dummy value
        return 0.0


    def __calc_tr(self, diff_index: int, high: float, low: float, prev_close: float, prev_open: float) -> pd.Series:

        # Wilder's Swing Index uses adapted version of True Range
        # Therefore, we define several methods that we will
        # be using and then index them out based on logic
        # Kaufman, Trading Systems and Methods, 2020, p.175

        if diff_index == 0:

            return (high - prev_close) - (0.50 * (low - prev_close)) + (0.25 * (prev_close - prev_open))

        if diff_index == 1:

            return (low - prev_close) - (0.50 * (high - prev_close)) + (0.25 * (prev_close - prev_open))

        if diff_index == 2:

            return (high - low) + (0.25 * (prev_close - prev_open))