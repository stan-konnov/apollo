import pandas as pd


class DistributionMomentsCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None


    def calculate_moving_dist_moments(self, mean: bool, std: bool, skew: bool, kurt: bool, z_score: bool) -> None:

        # Get rolling window object to calculate distribution moments
        rolling_window = self.dataframe['close'].rolling(window=self.window_size)

        if mean:

            # Calculate moving average
            self.dataframe['avg'] = rolling_window.mean()

        if std:

            # Calculate moving standard deviation
            self.dataframe['std'] = rolling_window.std()

        if skew:

            # Calculate moving skewness
            self.dataframe['skew'] = rolling_window.skew()

        if kurt:

            # Calculate moving kurtosis
            self.dataframe['kurt'] = rolling_window.kurt()

        if z_score:

            # Calculate moving z-score from mean and standard deviation
            self.dataframe['z_score'] = (
                (self.dataframe['close'] - self.dataframe['avg']) / self.dataframe['std']
            )