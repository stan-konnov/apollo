import numpy as np

from pandas.core.frame import DataFrame
from scipy.signal import argrelextrema


class PriceChannelCalculator:

    dataframe: DataFrame = None

    # Used in calculations of extrema
    # Defines how many points on either side
    # of peak we need to qualify something a peak
    order: int = 10


    def calculate_price_channel(self) -> None:

        # Build a list of 0-based indices
        # Saved on class for charting
        self.indices = np.arange(0, len(self.dataframe))

        # Calculate min and max extrema
        minimas_sls, maximas_sls = self.__calc_extrema()

        # Calculate lower bound and slopes from minimas
        self.lower_bound, lb_slopes = self.__calc_trendline(minimas_sls)

        # Calculate upper bound and slopes from maximas
        self.upper_bound, _ = self.__calc_trendline(maximas_sls)

        # Write lower bound into the dataframe
        self.dataframe['lower_bound'] = self.lower_bound

        # Write lower bound slopes into dataframe
        self.dataframe['lb_slopes'] = lb_slopes


    def __calc_extrema(self) -> tuple[list[list[float]], list[list[float]]]:

        # We first start by identifying indices
        # that meet the criteria of order parameter:
        # At least N points on both sides of the peak to be considered a peak
        min_indices = argrelextrema(self.dataframe['close'].values, np.less, order=self.order)[0]

        max_indices = argrelextrema(self.dataframe['close'].values, np.greater, order=self.order)[0]

        # Lists to hold extrema
        # Saved on class for charting
        self.minimas = []
        self.maximas = []

        # Loop through frame
        # Note: we loop and don't use iloc,
        # since we want to fill non-extrema positions with NaNs
        for i in range(0, len(self.dataframe), 1):

            # If currently iterated row index
            # matches presumed minima index
            if i in min_indices:

                # Minima found, add the close at this index
                self.minimas.append(self.dataframe.iloc[i]['close'])

            else:

                # Otherwise fill the position with NaN
                self.minimas.append(np.nan)

            # Repeat for maximas
            if i in max_indices:

                self.maximas.append(self.dataframe.iloc[i]['close'])

            else:

                self.maximas.append(np.nan)

        # Split extrema into sublists
        minimas_sls = self.__split_trailing(self.minimas)
        maximas_sls = self.__split_trailing(self.maximas)

        return (minimas_sls, maximas_sls)


    def __calc_trendline(self, extrema_sls: list[list[float]]) -> tuple[list[float], list[float]]:

        # List to hold concatenated trendlines
        # for every extrema sub-list
        trendline = []

        # List to hold slopes for every sub-list
        slopes = []

        # Since first and last sub-lists
        # contain only one extrema, we cannot
        # calculate coefficents only from one value
        # Therefore, we pad both sub-lists with closing prices

        # Loop through extrema sub-lists
        for i, extrema_sl in enumerate(extrema_sls):

            # If we are at the first sub-list
            if i == 0:

                # Pad it with the close
                extrema_sl[0] = self.dataframe.iloc[0]['close']

            # If we are at the last sub-list
            if i == len(extrema_sls) - 1:

                # Pad it with the close
                extrema_sl[-1] = self.dataframe.iloc[-1]['close']

            # Construct sublist indices
            indices = np.arange(0, len(extrema_sl))

            # Use provided extrema as y axis values
            y = np.array(extrema_sl)

            # Fill x axis with indices based off provided extrema
            x = np.arange(1, len(extrema_sl) + 1, 1)

            #  Handle indices that sit at NaN positions
            x_clean = x[~np.isnan(y)]
            y_clean = y[~np.isnan(y)]

            # Calculate slope and intercept coefficients between axes
            slope, intercept = np.polyfit(x_clean, y_clean, 1)

            # Use slope and intercept to calculate trendline
            trendline_sl = slope * indices + intercept

            # If we haven't arrived to the last sub-list yet
            if i != len(extrema_sls) - 1:

                # Remove last entry from trendline,
                # as it duplicates the first entry of next sub-list
                trendline_sl = np.delete(trendline_sl, -1)

            # Concatenate trendlines
            trendline = np.concatenate((trendline, trendline_sl))

            # Construct list of slopes for the sub-list
            sub_slops = np.full(len(trendline_sl), slope)

            # Unpack them into the outer list
            slopes.extend(sub_slops)

        return (trendline, slopes)


    def __split_trailing(self, extrema: list[float]) -> list[list[float]]:

        # Split extrema in sub-lists
        # such that every chunk (except first)
        # starts with trailing extrema of previous chunk
        # allowing us to calculate trendlines for each sub-list of extrema

        # List to hold splitted chunks
        chunks = []

        # List to hold individual values
        current_chunk = []

        # Loop through extrema
        for entry in extrema:

            # Add entry to current chunk
            current_chunk.append(entry)

            # If we are at extrema
            if ~np.isnan(entry):

                # Add current chunk to the rest of chunks
                chunks.append(current_chunk)

                # Start (next) current chunk with extrema
                current_chunk = [entry]

        # Append final filled chunk
        chunks.append(current_chunk)

        return chunks

