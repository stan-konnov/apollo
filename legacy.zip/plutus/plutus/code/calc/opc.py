from pandas.core.frame import DataFrame


class OHLCPercentageChangeCalculator:

    dataframe: DataFrame = None

    # A simple char to string map
    # In order to avoid repetition
    aspects: dict[str, str] = {
        'o': 'open',
        'h': 'high',
        'l': 'low',
        'c': 'close'
    }


    def calculate_ohlc_percentage_change(self) -> None:

        # Calculate OHLC bar-on-bar change
        self.__calc_bar_on_bar_change('o')
        self.__calc_bar_on_bar_change('h')
        self.__calc_bar_on_bar_change('l')
        self.__calc_bar_on_bar_change('c')

        # Calculate OHLC intra-bar change
        # Covering 6 possible unique combinations
        self.__calc_intra_bar_change(('o', 'h'))
        self.__calc_intra_bar_change(('o', 'l'))
        self.__calc_intra_bar_change(('o', 'c'))
        self.__calc_intra_bar_change(('h', 'l'))
        self.__calc_intra_bar_change(('h', 'c'))
        self.__calc_intra_bar_change(('l', 'c'))


    def __calc_bar_on_bar_change(self, aspect: str) -> None:

        # Use provided aspect to calculate change of next row
        self.dataframe[f"{aspect}_change"] = self.dataframe[
            self.aspects[aspect]
        ].pct_change()


    def __calc_intra_bar_change(self, aspects: tuple[str, str]) -> None:

        # Unpack aspects
        a, b = aspects

        # Use aspects to calculate change within same row
        self.dataframe[f"{a}_{b}_change"] = self.dataframe[
            [self.aspects[a], self.aspects[b]]
        ].pct_change(axis=1)[
            self.aspects[b]
        ]