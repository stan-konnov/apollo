import numpy as np

from pandas.core.frame import DataFrame


class MovingAverageCalculator:

    dataframe: DataFrame = None

    # Moving average to use
    ma: str = 'ema'

    # Moving average intervals to use
    intervals: list[int] = [14, 21]

    def __init__(self) -> None:

        self.ma_methods = {
            'sma': self.__calc_sma,

            'ema': self.__calc_ema
        }

    def calculate_moving_average(self) -> None:

        # Loop through every interval and calculate moving average
        for interval in self.intervals:

            self.ma_methods[self.ma](interval)

    def calculate_crossovers(self) -> None:

        # Unpack intervals
        short_ma, long_ma = self.intervals

        # Construct key for the dataframe
        key = f"{self.ma}_{short_ma}_{long_ma}"

        # Define empty column
        self.dataframe[f"{key}_crossover"] = 0.0

        # Identify crossover point
        self.dataframe[f"{key}_crossover"] = np.where(
            self.dataframe[f"{self.ma}_{short_ma}"] > self.dataframe[f"{self.ma}_{long_ma}"], 1.0, 0.0
        )

        # Identify it's position
        self.dataframe[f"{key}_position"] = self.dataframe[f"{key}_crossover"].diff()

    def __calc_sma(self, interval: int) -> None:

        self.dataframe[f"{self.ma}_{interval}"] = self.dataframe['close'].rolling(
            window=interval, min_periods=interval
        ).mean()

    def __calc_ema(self, interval: int) -> None:

        self.dataframe[f"{self.ma}_{interval}"] = self.dataframe['close'].ewm(
            span=interval, adjust=True, min_periods=interval
        ).mean()


