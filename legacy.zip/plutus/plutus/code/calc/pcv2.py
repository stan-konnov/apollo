import pandas as pd
import numpy as np

from scipy.stats import linregress


class PriceChannelCalculator:

    dataframe: pd.DataFrame = None

    window_size: int = None

    t_slope: list[float] = []
    l_bound: list[float] = []
    u_bound: list[float] = []

    bf_line: list[float] = []


    def calculate_price_channels(self) -> None:

        # Fill slopes, bounds and lbf arrays with N NaN, where N = window size
        self.t_slope = np.full((1, self.window_size - 1), np.nan).flatten().tolist()
        self.l_bound = np.full((1, self.window_size - 1), np.nan).flatten().tolist()
        self.u_bound = np.full((1, self.window_size - 1), np.nan).flatten().tolist()
        self.bf_line = np.full((1, self.window_size - 1), np.nan).flatten().tolist()

        # Calculate bounds and slope by using linear regression
        self.dataframe['close'].rolling(self.window_size).apply(
            self.__calc_lin_reg
        )

        # Write slopes to dataframe
        self.dataframe['slope'] = self.t_slope

        # Shift slopes to further compare direction
        self.dataframe['prev_slope'] = self.dataframe['slope'].shift(1)

        # Write bounds to the dataframe
        self.dataframe['l_bound'] = self.l_bound
        self.dataframe['u_bound'] = self.u_bound

        # Write line of best fit to the dataframe
        self.dataframe['lbf'] = self.bf_line


    def __calc_lin_reg(self, series: pd.Series) -> float:

        # Use indices for x
        x = series.index

        # Use closing prices for y
        y = series.values

        # Calculate slope and intercept, ignore rest
        slope, intercept, _, _, _ = linregress(x, y)

        # Preserve slope
        self.t_slope.append(slope)

        # Calculate line of best fit
        lbf = (slope * x + intercept)

        # Preserve LBF
        self.bf_line.append(lbf[-1])

        # Calculate standard deviation
        std = y.std()

        # Calculate lower and upper bounds
        # as 3 standard deviations above/below LBF
        lower_bound = lbf - std * 3
        upper_bound = lbf + std * 3

        self.l_bound.append(lower_bound[-1])
        self.u_bound.append(upper_bound[-1])

        # Return dummy float
        return 0.0