import boto3
import json
import os

ecs = boto3.client("ecs")

def nonesafe_loads(obj):
    if obj is not None:
        return json.loads(obj)

def invoke_task(
        strategy,
        cluster="stocks",
        task_def="arn:aws:ecs:eu-central-1:584159534805:task-definition/stocks-backtest:1",
        container_name="stocks-backtest",
        subnets=["subnet-083d5b294303631ef"],
        security_groups=["sg-0cd9f2d918a1e24bb"]
        ):

    response = ecs.run_task(
        cluster=cluster,
        count=1,
        launchType="FARGATE",
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': subnets,
                'securityGroups': security_groups,
                'assignPublicIp': 'DISABLED'
            }
        },
        overrides={
            'containerOverrides': [
                {
                    'name': container_name,
                    'environment': [
                        {
                            'name': 'STRATEGY',
                            'value': strategy
                        },
                    ]
                },
            ],
        },
        taskDefinition=task_def
    )
    
    return response