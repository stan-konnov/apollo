# Set up AWS session and other things

import boto3
import configparser
import os
import pandas as pd
import sagemaker
import time

from datetime import datetime
from sagemaker import image_uris

# TODO: Create reusable sagemaker role in terraform
role = "arn:aws:iam::584159534805:role/plutus-pipeline"

# Config file settings
config = configparser.ConfigParser()
config.read("../../config.ini")

model_prefix = config["pipeline"]["model_prefix"]
temp_path = config["pipeline"]["temp_file_path"]
region = config["pipeline"]["aws_region"]
bucket = config["pipeline"]["bucket"]
calc_indicator_output_file = config["pipeline"]["calc_indicator_output_file"]
training_data_file = config["pipeline"]["training_data_file"]
validation_data_file = config["pipeline"]["validation_data_file"]

# TODO: the skip columns thing needs to be made more scalable
# Number of columns to skip when compiling the X and y training
# sets.  X are the independent feature columns, and y is the
# independent feature (result) column
# Columns look like this:
# | row index | action | Ticker | time_period | datetime | feature1 | feature2 | ... |
# At least the following are expected to be skipped:
# Y: Nothing (row index seems to be skipped by default)
# X: action - datetime (row index seems to be skipped by default)
x_skip_columns = int(config["pipeline"]["x_skip_columns"])
y_skip_columns = int(config["pipeline"]["y_skip_columns"])


def train_linear_learner(strategy: str):

    bucket_prefix = f"{strategy}/"

    # Create temp file path
    if not os.path.exists(temp_path):
        os.makedirs(temp_path)

    model_name = strategy
    model_name_full = f"{model_prefix}-{model_name}"

    # Default session for SSO authentication
    # TODO: is this needed?
    #aws_profile = os.getenv(key="AWS_PROFILE")
    #if (aws_profile is not None):
    #    boto3.setup_default_session(profile_name=aws_profile)

    s3_client = boto3.client("s3")
    local_indicator_csv = f"{temp_path}/indicator_calcs.csv"
    s3_client.download_file(bucket, f"{bucket_prefix}{calc_indicator_output_file}", local_indicator_csv)
    indicator_csv = pd.read_csv(
        local_indicator_csv,
        #header=None
    )

    # prep_training_data does not take the row index into account when skipping
    # columns to convert to numpy and then dense tensor.  We need to account
    # for it here because we are using the csv shape as a reference, which is
    # the reason for the extra -1 in the dimension calculation
    feature_dimension = indicator_csv.shape[1] - 1
    
    # Set up and run training job

    container = image_uris.retrieve(region=region, framework="linear-learner")

    job_name = f"{model_name_full}-{time.strftime('%Y-%m-%d-%H-%M', time.gmtime())}"
    print("Job name is:", job_name)

    linear_training_params = {
        "RoleArn": role,
        "TrainingJobName": job_name,
        "AlgorithmSpecification": {"TrainingImage": container, "TrainingInputMode": "File"},
        "ResourceConfig": {"InstanceCount": 1, "InstanceType": "ml.c4.2xlarge", "VolumeSizeInGB": 10},
        "InputDataConfig": [
            {
                "ChannelName": "train",
                "DataSource": {
                    "S3DataSource": {
                        "S3DataType": "S3Prefix",
                        "S3Uri": f"s3://{bucket}/{bucket_prefix}{training_data_file}",
                        "S3DataDistributionType": "ShardedByS3Key",
                    }
                },
                "CompressionType": "None",
                "RecordWrapperType": "None",
            },
            {
                "ChannelName": "validation",
                "DataSource": {
                    "S3DataSource": {
                        "S3DataType": "S3Prefix",
                        "S3Uri": f"s3://{bucket}/{bucket_prefix}{validation_data_file}",
                        "S3DataDistributionType": "FullyReplicated",
                    }
                },
                "CompressionType": "None",
                "RecordWrapperType": "None",
            },
        ],
        "OutputDataConfig": {"S3OutputPath": f"s3://{bucket}/{bucket_prefix}model"},
        "HyperParameters": {
            "feature_dim": str(feature_dimension - x_skip_columns),
            "mini_batch_size": "10",
            "predictor_type": "regressor",
            "epochs": "10",
            "num_models": "32",
            "loss": "absolute_loss",
        },
        "StoppingCondition": {"MaxRuntimeInSeconds": 60 * 60},
    }


    sm = boto3.client('sagemaker', region_name=region)

    sm.create_training_job(**linear_training_params)

    status = sm.describe_training_job(TrainingJobName=job_name)["TrainingJobStatus"]
    print(status)

    sm.get_waiter("training_job_completed_or_stopped").wait(TrainingJobName=job_name)
    if status == "Failed":
        message = sm.describe_training_job(TrainingJobName=job_name)["FailureReason"]
        print("Training failed with the following error: {}".format(message))
        raise Exception("Training job failed")
    else:
        print("Training job probably succeeded")

    # Create model

    linear_hosting_container = {
        "Image": container,
        "ModelDataUrl": sm.describe_training_job(TrainingJobName=job_name)["ModelArtifacts"][
            "S3ModelArtifacts"
        ],
    }

    # Model names must be unique
    current_models = sm.list_models(NameContains=model_name_full)
    if model_name_full in (m["ModelName"] for m in current_models["Models"]):
        sm.delete_model(ModelName=model_name_full)
        print(f"deleted previously created model {model_name_full}")

    create_model_response = sm.create_model(
        ModelName=model_name_full, ExecutionRoleArn=role, PrimaryContainer=linear_hosting_container
    )

    print(create_model_response["ModelArn"])