import boto3
import configparser
import json
import os
import pandas as pd
import sagemaker
from sagemaker.transformer import Transformer

from plutus.code.backtesting_results import Backtesting

# Config file settings
# TODO: put this in a util or something
config = configparser.ConfigParser()
config.read('../../config.ini')

temp_path = config['pipeline']['temp_file_path']
bt_indicator_file_reduced = config['pipeline']['bt_indicator_file_reduced']
bt_indicator_file_trimmed = config['pipeline']['bt_indicator_file_trimmed']
bt_results_output_file = config['pipeline']['bt_results_output_file']
bt_scores_file = config['pipeline']['bt_scores_file']
bt_indicator_scores_final_file = config['pipeline']['bt_indicator_scores_final_file']
bucket = config['pipeline']['bucket']
aws_region = config['pipeline']['aws_region']
x_skip_columns = int(config['pipeline']['x_skip_columns'])


def backtesting_transform(strategy: str) -> None:
    """Run backtesting csv through the model endpoint to get scores
    """

    bucket_prefix = f"{strategy}/"

    bt_indicator_file_reduced_local = f"{temp_path}/{bt_indicator_file_reduced}"
    bt_indicator_file_trimmed_local = f"{temp_path}/{bt_indicator_file_trimmed}"
    bt_indicator_file_trimmed_s3_key = f"{bucket_prefix}{bt_indicator_file_trimmed}"
    bt_scores_s3_scores_key = f"{bucket_prefix}{bt_indicator_file_trimmed}.out"
    bt_scores_local = f"{temp_path}/backtesting-scores-file.out"
    bt_indicator_scores_final_local = f"{temp_path}/{bt_indicator_scores_final_file}"
    bt_indicator_scores_final_s3_key = f"{bucket_prefix}{bt_indicator_scores_final_file}"
    
    # Create temp file path
    if not os.path.exists(temp_path):
        os.makedirs(temp_path)

    s3_client = boto3.client("s3")
    s3_client.download_file(
        bucket,
        f"{bucket_prefix}{bt_indicator_file_reduced}",
        bt_indicator_file_reduced_local
    )

    # download csv and remove columns not related to independent features
    indicator_df = pd.read_csv(bt_indicator_file_reduced_local, index_col=0)
    indicator_df_trimmed = indicator_df.drop(indicator_df.iloc[:, :x_skip_columns], axis = 1)
    indicator_df_trimmed.to_csv(bt_indicator_file_trimmed_local, index=False, header=False)

    s3_client.upload_file(
        bt_indicator_file_trimmed_local,
        bucket,
        bt_indicator_file_trimmed_s3_key,
    )

    # Old output file must be deleted first to prevent some sort of parsing error
    s3_client.delete_object(Bucket=bucket, Key=bt_scores_s3_scores_key)

    # Get scores from model

    # Sagemaker session needs to have the region defined.  Running it
    # without the AWS_REGION env var requires that it be set as a param
    sm_session = sagemaker.Session(boto3.session.Session(region_name=aws_region))
    bt_transformer = Transformer(
        f"stocks-{strategy}",
        1,
        "ml.m4.xlarge",
        output_path=f"s3://{bucket}/{bucket_prefix}",
        sagemaker_session=sm_session,
        strategy="MultiRecord",
        assemble_with="Line",
        base_transform_job_name=strategy
    )
    bt_transformer.transform(
        f"s3://{bucket}/{bt_indicator_file_trimmed_s3_key}",
        content_type="text/csv",
        split_type="Line",
    )
    bt_transformer.wait()

    # Download scores and replace action column with scores column in csv
    # Scores file is one dict per line and looks like this:
    # {"score":0.894885301589965}
    # {"score":0.89979863166809}
    # ...
    # {"score":0.842833757400512}
    s3_client.download_file(bucket, bt_scores_s3_scores_key, bt_scores_local)
    scores = []
    with open(bt_scores_local, "r") as file:
        for line in file:
            scores.append(json.loads(line)["score"])

    indicator_df.drop(columns='action', inplace=True)
    indicator_df.insert(loc=0, column='score', value=scores)
    
    indicator_df.to_csv(bt_indicator_scores_final_local, header=True)

    s3_client.upload_file(
        bt_indicator_scores_final_local,
        bucket,
        bt_indicator_scores_final_s3_key,
    )

if __name__ == '__main__':
    backtesting_transform('buylow')
    backtesting('buylow')