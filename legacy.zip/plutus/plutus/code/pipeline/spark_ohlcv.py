from datetime import datetime, timedelta
from pyspark.sql import Window, DataFrame, SparkSession
from pyspark.sql.types import StructType

from plutus.code.utils.create_shared_input_spark \
    import create_single_series_input
from plutus.code.utils.read_config import read_config_file


def get_ohlcv(
    spark: SparkSession,
    strategy: str,
    s3_results_uri,
    database_url: str,
    marketstack_token: str,
    eod_token: str,
) -> tuple:

    start_time = datetime.now()
    print(f"Getting OHLCV at {start_time.strftime('%m/%d/%Y, %H:%M:%S')}")

    strat_config = read_config_file(strategy, spark=True)

    # Create empty dataframes
    training_df = spark.createDataFrame([], StructType([]))
    backtesting_df = spark.createDataFrame([], StructType([]))

    for ticker, ticker_value in strat_config['tickers'].items():
        for time_period in ticker_value['time_periods']:
            df = create_single_series_input(
                spark,
                ticker,
                start_date=time_period['start_date'],
                end_date=time_period['end_date'],
                mongo_database='stocks',
                database_url=database_url,
                marketstack_token=marketstack_token,
                eod_token=eod_token,
            )
            training_df = training_df.unionByName(df, allowMissingColumns=True)

    for ticker, ticker_value in strat_config['backtesting'].items():
        for time_period in ticker_value['time_periods']:
            df = create_single_series_input(
                spark,
                ticker,
                start_date=time_period['start_date'],
                end_date=time_period['end_date'],
                mongo_database='stocks',
                database_url=database_url,
                marketstack_token=marketstack_token,
                eod_token=eod_token,
            )
            backtesting_df = training_df.unionByName(df, allowMissingColumns=True)

    # Write the resulting OHLCV dataframes to S3 as CSVs just for debugging
    # purposes.  The intention is that the spark pipeline will use the
    # dataframes in the return value for further processing in the pipeline.
    training_df.write.option("header", "true").mode("overwrite").csv(
        f"{s3_results_uri}{strategy}/ohlcv-training"
    )
    backtesting_df.write.option("header", "true").mode("overwrite").csv(
        f"{s3_results_uri}{strategy}/ohlcv-backtesting"
    )
    
    return (training_df, backtesting_df)
