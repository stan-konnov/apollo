import boto3
import configparser
import os
from datetime import datetime, timedelta

from plutus.code.utils.create_shared_input import create_multiple_series_input

def get_time_period_tuples(tickers: dict) -> list[tuple[str, str, str]]:
    """ Create a list of tuples representing a each distinct
    time period/ticker to collect

    the tickers parameter is the ticker or backtesting dict of
    tickers from the strategy json config file
    """
    time_period_tuples = []
    for ticker, ticker_config in tickers.items():
        for period in ticker_config["time_periods"]:
            time_period_tuples.append(
                (ticker, period["start_date"], period["end_date"])
            )
    return time_period_tuples

def get_ohlcv(strategy: dict, strategy_name: str):
    """Fetches the OHLCV columns for the strategy and writes them to CSV

    Params:
        - strategy: This is actually an unstringified json from the strategy's json
                    config file
        - strategy_name: name of strategy json config file (minus .json extension)

    Required environment variables:
        - PRICES_API_URL:   URL of historical data endpoint
        - EXCHANGE_OT_URL:  URL of the historical data exchange details endpoint 
        - PRICES_API_TOKEN: API token of historical data endpoint
        - ML_S3_BUCKET:     Bucket for training data
        - MONGO_DATABASE:   Mongo database name
        - MONGO_HOST:       Private hostname of mongo endpoint
        - MONGO_PORT:       27017
        - MONGO_PROTOCOL:   mongodb+srv
        - MONGO_USERNAME:   Mongo user
        - MONGO_PASSWORD:   Mongo password
        - DATABASE_URL:     Mongo connection string (not used here I think)
    """

    start_time = datetime.now()
    print(f"Getting OHLCV at {start_time.strftime('%m/%d/%Y, %H:%M:%S')}")

    # Config file settings
    config = configparser.ConfigParser()
    config.read("../../config.ini")

    result_file_name = config["pipeline"]["ohlcv_file"]
    bt_result_file_name = config["pipeline"]["backtesting_ohlcv_file"]
    temp_path = config["pipeline"]["temp_file_path"]
    bucket = config["pipeline"]["bucket"]

    bucket_prefix = f"{strategy_name}/"

    # Create temp file path
    if not os.path.exists(temp_path):
        os.makedirs(temp_path)

    time_period_tuples = get_time_period_tuples(strategy["tickers"])
    temp_path_full = f"{temp_path}/{result_file_name}"
    create_multiple_series_input(temp_path_full, time_period_tuples)

    s3 = boto3.client("s3")
    s3.upload_file(temp_path_full, bucket, f"{bucket_prefix}{result_file_name}")

    bt_time_period_tuples = get_time_period_tuples(strategy['backtesting'])
    bt_temp_path_full = f"{temp_path}/{bt_result_file_name}"
    create_multiple_series_input(bt_temp_path_full, bt_time_period_tuples)

    print(f"backtesting temp file details: {os.stat(bt_temp_path_full)}")

    s3.upload_file(bt_temp_path_full, bucket, f"{bucket_prefix}{bt_result_file_name}")

    end_time = datetime.now()
    execution_time = end_time - start_time
    print(f"OHLCV done at {end_time.strftime('%m/%d/%Y, %H:%M:%S')} in {str(execution_time)}")

if __name__ == '__main__':
    get_ohlcv()
