import boto3
import configparser
import os
import importlib

import pandas as pd

from backtesting import Backtest

from plutus.code.backtesting_results_v2 import Mutator, StrategyBacktesting

# Config file settings
# TODO: put this in a util or something
config = configparser.ConfigParser()
config.read('../../config.ini')

temp_path = config['pipeline']['temp_file_path']
bucket = config['pipeline']['bucket']
bt_indicator_scores_final_file = \
    config['pipeline']['bt_indicator_scores_final_file']
bt_results_output_file = config['pipeline']['bt_results_output_file']


def time_period_label(ticker: str, time_period: str) -> str:
    
    return \
f"""    -------------------------------
    {ticker}

    Time period:
    {time_period}
"""

def strategy_label(strategy_name: str) -> str:
    
    return \
f"""################################################
# Backtesting results for {strategy_name}
################################################
    
"""

def configurations_list(strategy_config: dict) -> list[tuple]:
    """Creates an iterable representing a list of config tuples
    
    Looks like:
    [
        (0.005, 0.02, 0.5),
        (0.01, 0.01, 0.7),
        (0.005, 0.02, 1.0)
    ]
    """

    sl_list = strategy_config['backtesting_config']['stop_loss']
    tp_list = strategy_config['backtesting_config']['take_profit']
    st_list = strategy_config['backtesting_config']['signal_threshold']
    
    for sl in sl_list:
        for tp in tp_list:
            for st in st_list:
                yield (sl, tp, st)

def backtesting_v2(strategy_config: dict, strategy_name: str) -> None:

    bucket_prefix = f"{strategy_name}/"
    window_size = strategy_config['backtesting_config']['window_size']

    bt_indicator_scores_final_local = \
        f"{temp_path}/{bt_indicator_scores_final_file}"
    bt_indicator_scores_final_s3_key = \
        f"{bucket_prefix}{bt_indicator_scores_final_file}"
    stats_file_local = f"{temp_path}/{bt_results_output_file}"
    
    # Create temp file path
    if not os.path.exists(temp_path):
        os.makedirs(temp_path)

    s3_client = boto3.client("s3")
    s3_client.download_file(
        bucket,
        bt_indicator_scores_final_s3_key,
        bt_indicator_scores_final_local
    )

    full_dataset = pd.read_csv(bt_indicator_scores_final_local, index_col=0)

    with open(stats_file_local, 'w') as file_handle:
        file_handle.write(strategy_label(strategy_name))

    # Level 0: Separate by ticker
    for ticker in full_dataset['ticker'].unique():
        ticker_dataset = full_dataset.loc[full_dataset['ticker'] == ticker]

        # Level 1: separate by contiguous time period
        for time_period in ticker_dataset['time_period'].unique():
            contiguous_dataset = full_dataset.loc[
                full_dataset['time_period'] == time_period
            ]

            # Create mutator for the current ticker
            mutator = Mutator()
            mutator.dataframe = contiguous_dataset
            mutator.prepare()

            # Backtest and consume the stats for each configured tuple
            # of: (stop_loss, take_profit, signal_threshold)
            #
            # window_size is just one value to reduce the number of
            # iterations, since this likely won't change much during
            # experiments
            for sl, tp, st in configurations_list(strategy_config):

                StrategyBacktesting.window_size = window_size
                StrategyBacktesting.stop_loss_level = sl
                StrategyBacktesting.take_profit_level = tp
                StrategyBacktesting.signal_threshold = st

                bt = Backtest(mutator.dataframe, StrategyBacktesting, cash=1000)
                stats = bt.run()

                with open(stats_file_local, 'a') as file_handle:
                    file_handle.write(time_period_label(ticker, time_period))
                    file_handle.write(StrategyBacktesting.to_str())
                    file_handle.write(str(stats))
                    file_handle.write('\n\n')

    s3_client.upload_file(
        stats_file_local,
        bucket,
        f"{bucket_prefix}{bt_results_output_file}"
    )


if __name__ == '__main__':

    from plutus.code.utils.read_config import read_config_file
    strategy_config = read_config_file('buylow')

    backtesting_v2(strategy_config=strategy_config, strategy_name='buylow')