import boto3
import configparser
import json
import os
import pandas as pd
import random
import sagemaker
import time
from datetime import datetime
from multiprocessing.pool import ThreadPool
from sagemaker.processing import ProcessingInput, ProcessingOutput, Processor

from plutus.code.calc import (
    PriceChannelCalculator,
    DistributionMomentsCalculator,
    SupportAndResistanceCalculator,
    RelativeStrengthIndexCalculator
)
from plutus.code.signal_marker import SignalMarker

# Config file settings
# TODO: wrap this up into a function or something in utils
config = configparser.ConfigParser()
config.read("../../config.ini")

ohlcv_file = config["pipeline"]["ohlcv_file"]
backtesting_ohlcv_file = config["pipeline"]["backtesting_ohlcv_file"]
temp_path = config["pipeline"]["temp_file_path"]
bucket = config["pipeline"]["bucket"]
region = config["pipeline"]["aws_region"]
rows_per_job = int(config["pipeline"]["rows_per_job"])
min_rows_per_job = int(config["pipeline"]["min_rows_per_job"])
rolling_window_size = int(config["pipeline"]["rolling_window_size"])
max_calc_instances = int(config["pipeline"]["max_calc_instances"])
calc_instance_type = config["pipeline"]["calc_instance_type"]
train_indicator_input_prefix = config["pipeline"]["train_indicator_input_prefix"]
train_indicator_output_prefix = config["pipeline"]["train_indicator_output_prefix"]
bt_indicator_input_prefix = config["pipeline"]["bt_indicator_input_prefix"]
bt_indicator_output_prefix = config["pipeline"]["bt_indicator_output_prefix"]
calc_task_args_file = config["pipeline"]["calc_task_args_file"]

calc_task_args_path = f"{temp_path}/{calc_task_args_file}"

job_timestamp = datetime.now().strftime('%Y%M%dT%H%M%S')

def task_arg_chunks(full_list, num_chunks):
    chunk_size = len(full_list) // num_chunks

    # Make the return value iterable
    for index in range(0, len(full_list), chunk_size):

        # Handle case where length and chunk_size are not perfectly
        # divisible, and this is the second to last chunk.  Just add
        # the remainder to this chunk and terminate the loop to not
        # process the remainder as an extra chunk
        if index + chunk_size + chunk_size > len(full_list):
            yield full_list[index : len(full_list)]
            break

        # The following will handle all other chunks, and it would create
        # an extra chunk for the remainder if the above break were to be
        # removed
        else:
            yield full_list[index : index + chunk_size]

def task(mp_id, strategy):

    # Delay the processing job/instance creation because it seems that
    # too many simultaneous job requests may be causing AWS to fail and/or
    # ignore some of them.  This sleeps between 1 - 5 seconds.
    time.sleep(random.uniform(1.0, 5.0))

    boto_session = boto3.Session(region_name=region)
    sagemaker_session = sagemaker.Session(boto_session=boto_session)

    bucket_prefix = f"{strategy}/"

    # TODO: un-hardcode role, image, instance_type
    # Cast all env vars to str
    indicator_processor_manager = Processor(
    sagemaker_session=sagemaker_session,
    role="arn:aws:iam::584159534805:role/plutus-pipeline",
    image_uri="584159534805.dkr.ecr.eu-central-1.amazonaws.com/stocks-plutus",
    entrypoint=["docker_cmd/calculate_indicators.sh"],
    instance_count=1,
    instance_type=calc_instance_type,
    env={
        "TASK_ARG_INDEX": str(mp_id),
        "STRATEGY": strategy,
    },
    )

    inputs = [
        ProcessingInput(
            source=f"s3://{bucket}/{bucket_prefix}",
            destination=f"{temp_path}/input"
        ),
    ]

    outputs = [
        ProcessingOutput(
            destination=f"s3://{bucket}/{bucket_prefix}",
            source=f"{temp_path}/output"
        ),
    ]

    indicator_processor_manager.run(
        job_name=f"plutus-calc-indicators-{strategy}-{job_timestamp}-{mp_id}",
        inputs=inputs,
        outputs=outputs,
    )

def prep_dataset(full_dataset: pd.DataFrame, stage: str, strategy: str) -> list[tuple[int, str]]:
    """
    full_dataset: pandas DataFrame representing entire ohlcv csv
    stage: training or backtesting
    """

    bucket_prefix = f"{strategy}/"
    id = 0
    task_args = []

    # Level 0: separate by ticker
    for ticker in full_dataset['ticker'].unique():
        ticker_dataset = full_dataset.loc[full_dataset['ticker'] == ticker]

        # Level 1: separate by contiguous time period
        for time_period in ticker_dataset['time_period'].unique():
            contiguous_dataset = full_dataset.loc[
                full_dataset['time_period'] == time_period
            ]
            row_count = contiguous_dataset.index[0]
            last_row_index = contiguous_dataset.index[-1]

            # Level 3: separate by a combination of
            # - job size (rows_per_job)
            # - rolling window size
            # - minimum job size (min_rows_per_job): anything smaller 
            #   gets added to the previous job
            while row_count <= last_row_index - rolling_window_size:

                # next_row_count represents the first row of the next job
                # (note that this does not factor in the extra rolling_window of
                # "warm-up" data which will be added to the beginning of the data set)
                next_row_count = row_count + rows_per_job + rolling_window_size
                
                # Handle case at the end of the contiguous time period data set
                # where the next job is too small to be useful.  We'll add it to the
                # current job and make it the last one of this data set.
                # next_row_count represents the non-existent row after the end
                # of the contiguous time period data set.
                if last_row_index - next_row_count < min_rows_per_job:
                    next_row_count = last_row_index + 1 
                
                # Handle case where the end of the contiguous time period data set
                # is reached (i.e. the final partial job of the set).
                # next_row_count represents the non-existent row after the end
                # of the contiguous time period data set.
                if next_row_count > last_row_index:
                    next_row_count = last_row_index + 1

                contiguous_subset_start = row_count
                contiguous_subset_end = next_row_count - 1
                task_dataframe = full_dataset.loc[contiguous_subset_start:contiguous_subset_end]

                # Create calc_indicator task input file and send to s3
                if stage == 'training':
                    indicator_input_prefix = train_indicator_input_prefix
                elif stage == 'backtesting':
                    indicator_input_prefix = bt_indicator_input_prefix

                task_file_name = f'{indicator_input_prefix}{id}.csv'
                task_file_path = f'{temp_path}/{task_file_name}'
                task_dataframe.to_csv(task_file_path, header=True)

                s3 = boto3.client("s3")
                s3.upload_file(task_file_path, bucket, f"{bucket_prefix}{task_file_name}")
                
                task_args.append((
                    id,
                    task_file_name,
                    stage
                ))
                row_count = next_row_count - rolling_window_size
                id += 1

    return task_args


def delete_old_indicator_files(indicator_file_prefix: str, strategy: str):

    bucket_prefix = f"{strategy}/"

    bucket_resource = boto3.resource('s3').Bucket(bucket)
    indicator_key_prefix = f"{bucket_prefix}{indicator_file_prefix}"
    objects = bucket_resource.objects.filter(Prefix=indicator_key_prefix)

    indicator_key_list = [{'Key': o.key} for o in objects]

    # S3's delete_objects() takes max 1000 objects,
    # so this needs to be called multiple times
    chunk_size = 1000
    paginated_ind_key_list = []
    for index in range(0, len(indicator_key_list), chunk_size):
        paginated_ind_key_list.append(indicator_key_list[index : index + chunk_size])

    for ind_key_list_page in paginated_ind_key_list:
        if len(ind_key_list_page):
            s3_client = boto3.client('s3')
            s3_client.delete_objects(Bucket=bucket, Delete={'Objects': ind_key_list_page})
            

def calc_indicator_manager(strategy):

    input_path = f"{temp_path}/input"
    output_path = f"{temp_path}/output"
    ohlcv_file_local = f"{input_path}/{ohlcv_file}"
    bt_ohlcv_file_local = f"{input_path}/{backtesting_ohlcv_file}"
    bucket_prefix = f"{strategy}/"

    # Create temp file path directory
    if not os.path.exists(input_path):
        os.makedirs(input_path)
    s3 = boto3.client("s3")
    s3.download_file(bucket, f"{bucket_prefix}{ohlcv_file}", ohlcv_file_local)
    s3.download_file(bucket, f"{bucket_prefix}{backtesting_ohlcv_file}", bt_ohlcv_file_local)

    full_dataset_training = pd.read_csv(ohlcv_file_local, header=0, index_col=0)
    full_dataset_training.index.name = 'index'

    full_dataset_backtesting = pd.read_csv(bt_ohlcv_file_local, header=0, index_col=0)
    full_dataset_backtesting.index.name = 'index'

    task_args = prep_dataset(full_dataset_training, stage='training', strategy=strategy)
    bt_task_args = prep_dataset(full_dataset_backtesting, stage='backtesting', strategy=strategy)

    # Delete old indicator output files before starting
    delete_old_indicator_files(train_indicator_output_prefix, strategy=strategy)
    delete_old_indicator_files(bt_indicator_output_prefix, strategy=strategy)

    # Create file on s3 with the task_arg_chunks
    # Sending this as an env var to the processing jobs does not always work
    # because env vars are limited to 256 chars
    task_arg_chunk_list = []
    for task_arg_chunk in task_arg_chunks(task_args + bt_task_args, max_calc_instances):
        task_arg_chunk_list.append(task_arg_chunk)

    with open(calc_task_args_path, 'w') as file_handle:
        file_handle.write(json.dumps(task_arg_chunk_list))

    s3.upload_file(calc_task_args_path, bucket, f"{bucket_prefix}{calc_task_args_file}")

    # Run max_calc_instances processing jobs, splitting the sub-tasks evenly
    # Each processing job instance will run its sub-tasks in parallel using
    # multiprocessing using all of its cpus
    # Each job gets its list/chunk of sub-tasks by referring to the
    # calc_task_args_file from the s3 bucket
    with ThreadPool(processes=max_calc_instances) as pool:
        pool.starmap(task, [(mp_id, strategy) for mp_id in range(max_calc_instances)])