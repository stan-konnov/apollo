import boto3
import configparser
import os

import pandas as pd
import numpy as np
import io
import sagemaker.amazon.common as smac

# Constants

# Number of columns to skip when compiling the X and y training
# sets.  X are the independent feature columns, and y is the
# independent feature (result) column
# Columns look like this:
# | row index | action | ticker | time_period | datetime | feature1 | feature2 | ... |
# At least the following are expected to be skipped:
# Y: Nothing (row index seems to be skipped by default)
# X: action - datetime (row index seems to be skipped by default)
Y_SKIP_COLUMNS = 0
X_SKIP_COLUMNS = 4

# TODO: Create reusable sagemaker role in terraform
ROLE = "arn:aws:iam::584159534805:role/plutus-pipeline"

# Config file settings
# TODO: put this in a util or something
config = configparser.ConfigParser()
config.read("../../config.ini")

model_prefix = config["pipeline"]["model_prefix"]
temp_path = config["pipeline"]["temp_file_path"]
bucket = config["pipeline"]["bucket"]
region = config["pipeline"]["aws_region"]
configured_size = int(config["pipeline"]["rolling_window_size"])
calc_instance_type = config["pipeline"]["calc_instance_type"]
train_indicator_output_prefix = config["pipeline"]["train_indicator_output_prefix"]
bt_indicator_output_prefix = config["pipeline"]["bt_indicator_output_prefix"]
calc_indicator_output_file = config["pipeline"]["calc_indicator_output_file"]
bt_indicator_file_reduced = config["pipeline"]["bt_indicator_file_reduced"]
training_data_file = config["pipeline"]["training_data_file"]
validation_data_file = config["pipeline"]["validation_data_file"]

# TODO: use me from utils
def define_final_columns() -> list[str]:

    # Return a list of columns we expect in the final dataframe
    return [
        'action', 'ticker', 'time_period', 'datetime',
        'open', 'high', 'low', 'close', 'volume',
        'mov_skew', 'mov_kurt', 'mov_avg', 'mov_std', 'lb_slopes', 'lower_bound', 'rsi',
    ]

# TODO: use me from utils
def normalize_produced_dataframe(dataframe: pd.DataFrame, drop_action: bool = False) -> pd.DataFrame:

    # Get produced columns
    columns = dataframe.columns.to_list()

    # Loop through columns and move SR levels into separate list
    sr_levels = []

    for column in columns:
        if 'sr_level' in column:
            sr_levels.append(column)

    # Sort extracted SR levels numerically (by last integer)
    sr_levels = sorted(sr_levels, key=lambda x: int(x[len(x) - 1]))

    # Get columns we would like in final dataframe
    columns = define_final_columns()

    # Expand them with SR levels
    columns = columns + sr_levels

    if drop_action:

        columns = columns[1:]

    # Rearrange dataframe columns
    dataframe = dataframe[columns]

    # Fill missing cells across the dataframe with an ignorable value
    dataframe.fillna(-1, inplace=True)

    return dataframe

def reduce_csv(strategy: str, stage: str) -> pd.DataFrame:
    """Reduce indicator output files to 1 csv and write to s3

    stage: backtesting|training
    """

    bucket_prefix = f"{strategy}/"

    if stage == 'training':
        reduced_data_filename = calc_indicator_output_file
        indicator_key_prefix = f"{bucket_prefix}{train_indicator_output_prefix}"
    elif stage == 'backtesting':
        reduced_data_filename = bt_indicator_file_reduced
        indicator_key_prefix = f"{bucket_prefix}{bt_indicator_output_prefix}"

    s3_client = boto3.client('s3')

    # Delete the old reduced data file if it exists
    response = s3_client.delete_object(Bucket=bucket, Key=f"{bucket_prefix}{reduced_data_filename}")

    # Create temp file path
    if not os.path.exists(temp_path):
        os.makedirs(temp_path)

    # Download indicator files from s3
    bucket_resource = boto3.resource('s3').Bucket(bucket)
    indicator_objects = bucket_resource.objects.filter(Prefix=indicator_key_prefix)
    indicator_file_names = [o.key.removeprefix(bucket_prefix) for o in indicator_objects]

    for indicator_file_name in indicator_file_names:
        s3_client.download_file(
            bucket,
            f"{bucket_prefix}{indicator_file_name}",
            f"{temp_path}/{indicator_file_name}"
        )


    model_name = strategy
    model_name_full = f"{model_prefix}-{model_name}"

    # Reduce indicator files to one dataframe
    indicator_df_list = []
    for indicator_file_name in indicator_file_names:
        temp_df = pd.read_csv(f"{temp_path}/{indicator_file_name}")
        temp_df.set_index(keys='index', drop=True, inplace=True)
        indicator_df_list.append(temp_df)

    data = pd.concat(indicator_df_list, axis=0, sort=False).sort_index()

    # run normalization function to organize columns and deal with NaNs
    data = normalize_produced_dataframe(data)
    
    data.to_csv(reduced_data_filename)

    # Copy reduced csv to s3
    s3_client.upload_file(
            reduced_data_filename,
            bucket,
            f"{bucket_prefix}{reduced_data_filename}"
        )

    return data

def prep_training_data(strategy: str):

    bucket_prefix = f"{strategy}/"

    # Reduce the calc indicator outputs for both the backtesting
    # and training.  We then need to convert it for training only
    # (the backtester will just consume the csv from s3)
    reduce_csv(strategy, 'backtesting')
    data = reduce_csv(strategy, 'training')

    # Convert the pandas df to dense tensor for linear learner

    # Mark each of the rows as either training, validation or testing
    # based on random numbers
    # 70% of the dataset is for training
    # 30% of the dataset is for validation
    # Testing/backtesting to be done with a different dataset
    rand_split = np.random.rand(len(data))
    train_list = rand_split < 0.7
    val_list = rand_split >= 0.7

    # data_train is the randomized subset of data for training
    # data_val is the randomized subset of data for validation
    data_train = data[train_list]
    data_val = data[val_list]

    # Create X (independent) and y (dependent) datasets to feed into the
    # linear learner algorithm for training

    train_y = data_train.iloc[:, Y_SKIP_COLUMNS].to_numpy()
    train_X = data_train.iloc[:, X_SKIP_COLUMNS:].to_numpy()

    val_y = data_val.iloc[:, Y_SKIP_COLUMNS].to_numpy()
    val_X = data_val.iloc[:, X_SKIP_COLUMNS:].to_numpy()

    # Save temporary training files in bucket for training job
    # In the AWS example code for Linear Learner, they pass the data files
    # as dense tensor files.  We are doing the same here, as more research
    # will be needed to see if other formats are allowed or desireable.

    s3_client = boto3.client('s3')

    f = io.BytesIO()
    smac.write_numpy_to_dense_tensor(f, train_X.astype("float32"), train_y.astype("float32"))
    f.seek(0)
    s3_client.upload_fileobj(f, bucket, f"{bucket_prefix}{training_data_file}")
    
    f = io.BytesIO()
    smac.write_numpy_to_dense_tensor(f, val_X.astype("float32"), val_y.astype("float32"))
    f.seek(0)
    s3_client.upload_fileobj(f, bucket, f"{bucket_prefix}{validation_data_file}")


if __name__ == '__main__':
    prep_training_data('buylow')
