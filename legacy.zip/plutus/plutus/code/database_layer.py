import os
import pymongo

from datetime import datetime
from dateutil.relativedelta import relativedelta
from pytz import timezone

from dotenv import load_dotenv


class DatabaseLayer:

    # Database instance
    database = None


    def __init__(self) -> None:

        # Load in environment
        load_dotenv()

        # Populate necessary variables
        ENV = os.getenv('ENV')
        DATABASE_URL = os.getenv('DATABASE_URL')
        DATABASE_DEV_URL = os.getenv('DATABASE_DEV_URL')
        MONGO_DATABASE = os.getenv('MONGO_DATABASE')

        # Initialize the client
        if ENV == 'local':

            # Add port if running locally
            client = pymongo.MongoClient(DATABASE_DEV_URL)

        else:

            # Avoid port on cloud environment
            client = pymongo.MongoClient(DATABASE_URL)

        # Initialize the database connection
        self.database = client[MONGO_DATABASE]

        # Setup collection(s) and indexing
        self.__setup()


    def __setup(self) -> None:

        # Define collection to use throughout lifetime
        self.prices_collection = self.database['Prices']

        # Setup unique compound index: ticker and datetime
        self.prices_collection.create_index(
            [
                ('ticker', pymongo.ASCENDING),
                ('datetime', pymongo.ASCENDING),
            ]
        )


    def check_prices(self, ticker: str, start_dt: datetime, end_dt: datetime) -> bool:

        # Query earliest price point for provided ticker
        start_price_point = next(
            self.prices_collection.find(
                {
                    'ticker': ticker,
                    'datetime': {'$gte': start_dt, '$lte': end_dt}
                }
            ).sort(
                'datetime', pymongo.ASCENDING
            ).limit(1),
            None
        )

        # Query latest price point for provided ticker
        end_price_point = next(
            self.prices_collection.find(
                {
                    'ticker': ticker,
                    'datetime': {'$gte': start_dt, '$lte': end_dt}
                }
            ).sort(
                'datetime', pymongo.DESCENDING
            ).limit(1),
            None
        )

        # We check only for presence of starting point,
        # since if starting point exists, so is the ending point
        # (those are the same entities in case of only 1 data entry)
        #
        # We return falsy bool if no starting point exists
        if start_price_point is None:

            return False

        # Get end day of the week
        wd = datetime.weekday(end_dt)

        # Declare deltas for potential lookback
        deltas = { 5: 1, 6: 2 }

        # If provided end datetime falls on the weekend
        if wd in deltas:

            # We trace back to first available trading day (Friday)
            end_dt = end_dt - relativedelta(
                days=deltas[wd]
            )

        # Otherwise, we subtract single day, since end point is always exlusive
        else:

            end_dt = end_dt - relativedelta(days=1)

        # Prices are available if provided
        # start and end are within queried margins
        prices_are_available = (
            start_dt.date() >= start_price_point['datetime'].date() and
            end_dt.date() <= end_price_point['datetime'].date()
        )

        return prices_are_available


    def read_prices(self, ticker: str, start_dt: datetime, end_dt: datetime) -> list[dict]:

        # Query prices starting from provided point or later
        prices = self.prices_collection.find(
            {
                'ticker': ticker,
                'datetime': { '$gte': start_dt, '$lt': end_dt }
            },
            {
                '_id': False,
                'ticker': False,
                'gmtoffset': False,
                'timestamp': False
            }
        )

        return prices


    def write_prices(self, ticker: str, prices_response: list[dict]) -> None:

        # List for upsert operations
        prices_to_upsert = []

        # Declare format to use in parsing to/from datetime
        dt_format = '%Y-%m-%d %H:%M:%S'

        # Loop through response
        for price_json in prices_response:

            # Construct datetime object from incoming datetime string
            dt = datetime.strptime(price_json['datetime'], dt_format)

            # Localize to UTC
            dt = timezone('UTC').localize(dt)

            # Convert to Eastern Time
            dt = dt.astimezone(timezone('US/Eastern'))

            # To string and back, such that we save it
            # as mutated datetime object without any timezone
            dt = datetime.strptime(dt.strftime(dt_format), dt_format)

            # Override datetime string with datetime object
            price_json['datetime'] = dt

            # Create input
            price_object = pymongo.UpdateOne(
                { 'ticker': ticker, 'datetime': dt },
                { '$set': { 'ticker': ticker, **price_json } },
                upsert=True
            )

            # Pack into list
            prices_to_upsert.append(price_object)

        # Bulk upsert created objects
        self.prices_collection.bulk_write(prices_to_upsert)