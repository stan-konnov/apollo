import asyncio
import json
import pytz
import time
import warnings

from datetime import datetime

from plutus.code.api_connector import ApiConnector
from plutus.rtp.timer import Timer
from plutus.rtp.window import Window
from plutus.rtp.runner import run


def is_valid_trading_day(exchange_holidays: list[str]) -> bool:

    now = datetime.now()

    # Check if today's a potential trading day
    is_td = now.weekday() not in (5, 6)

    # Even if it's a trading day and is market hours
    # Check against API that factors in exchange holidays
    not_a_holiday = now.strftime('%Y-%m-%d') not in exchange_holidays

    return is_td and not_a_holiday


def is_valid_processing_timeframe() -> bool:

    # Now as Eastern Time
    et_dt = datetime.now().astimezone(pytz.timezone('US/Eastern'))

    # Format a string out of datetime
    dt_str = et_dt.strftime('%H:%M:%S')

    # String compare against our relevant margins:
    # First 3 hours of trading day (Eastern Time)
    valid_processing_timeframe = '09:30:00' <= dt_str <= '12:30:00'

    return valid_processing_timeframe


def construct_windows(tickers: list[str]) -> list[Window]:

    windows: list[Window] = []

    # Construct windows
    for ticker in tickers:

        window = Window(ticker)
        window.load()
        windows.append(window)

    return windows


async def main():

    # Initialize starting UTC datetime
    # to reconstruct windows on next day
    starting_dt = datetime.now().astimezone(pytz.utc)

    # Initialize connector for necessary checks
    ac = ApiConnector()

    # Get list of dates that contain exchange holidays
    exchange_holidays = ac.get_exchange_holidays()

    # Ignore future warnings from sklearn
    warnings.filterwarnings("ignore")

    # Consume config
    config_file = open(f"./config.json")
    config = json.load(config_file)
    config_file.close()

    print('Running main with:')
    print(config)

    # Triggers loop every N (28-07-2023: every one minute)
    timer = Timer()

    # Rolling window for every ticker
    windows = construct_windows(config['tickers'])

    # Run main loop
    while True:

        # Check if valid trading day
        valid_trading_day = is_valid_trading_day(exchange_holidays)

        # Avoid any further processing if not a trading day
        if not valid_trading_day:

            print('Not a trading day. Further ops are omitted')

            # Sleep for 1 minute to avoid cluttering logs
            time.sleep(60)

            continue

        # Initialize current UTC datetime
        current_dt = datetime.now().astimezone(pytz.utc)

        # We consider new trading day only after 10:00 (UTC)
        # to have a safety margin before fetching historical data
        # since API delivers historical time series with few hours delay
        new_day_started = (
            current_dt.date() > starting_dt.date() and
            current_dt.strftime('%H:%M:%S') >= '10:00:00'
        )

        if new_day_started:

            print('New trading day, reconstructing windows')

            windows = construct_windows(config['tickers'])

            # Reset the date
            starting_dt = current_dt

        # Check if valid processing timeframe
        valid_processing_timeframe = is_valid_processing_timeframe()

        # Avoid any further processing if not inside necessary timeframe
        if not valid_processing_timeframe:

            print('Not yet inside valid processing timeframe. Further ops are omitted')

            # Sleep for 1 minute to avoid cluttering logs
            time.sleep(60)

            continue

        # Check if loop step passed
        loop_restarted = timer.check_loop()

        if loop_restarted:

            # List of coroutines for every ticker
            coroutines = []

            # Loop through windows
            for window in windows:

                # Create a coroutine for every ticker and append to list
                coroutines.append(
                    asyncio.create_task(run(window))
                )

            # Launch all coroutines
            await asyncio.gather(*coroutines)


asyncio.get_event_loop().run_until_complete(main())