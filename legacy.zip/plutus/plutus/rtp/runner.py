from plutus.rtp.window import Window


async def run(window: Window):

    # Check if historical data is available from API
    if window.hist_data_available:

        # Consume incoming minute and shift window forward
        # Additionally, check if latest bar is available from API
        latest_bar_available = await window.shift()

        # Proceed only if latest bar is available
        if latest_bar_available:

            # Calculate rolling values
            await window.calculate()

            # Dispatch signal
            await window.dispatch()