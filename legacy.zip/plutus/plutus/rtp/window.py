import os

import pandas as pd

from datetime import datetime, timedelta
from slack_sdk.webhook.client import WebhookClient
from pytz import timezone

from plutus.code.api_connector import ApiConnector
from plutus.code.strategies.custom_long import CustomLongStrategy


class Window:

    ticker: str

    connector: ApiConnector

    rolling_window: pd.DataFrame

    calculation_window: pd.DataFrame

    signal_client: WebhookClient

    slice: int = 125

    dispatching_allowed: bool = True

    dt_format = '%Y-%m-%d %H:%M:%S'


    def __init__(self, ticker: str) -> None:

        self.ticker = ticker

        # Populate connector with:
        # data source, ticker, request margins
        self.connector = ApiConnector()

        self.connector.ticker = ticker

        start, end = self.__get_start_end()

        self.connector.start_date = start
        self.connector.end_date = end

        # Initialize strategy to apply
        self.strategy = CustomLongStrategy()

        # Intialize signaling client (slack webhook)
        self.signal_client = WebhookClient(os.getenv('SLACK_WEBHOOK_URL'))

        # A flag that controls the whole processing
        # of the window based on availability
        # of historical prices from API
        self.hist_data_available = True

    def load(self) -> None:

        # Request prices
        try:

            prices = self.connector.request_daily_prices()

        # Catch a missing disk IO = no historical prices from API
        except:

            # Flip the controlling flag
            self.hist_data_available = False

            # Exit and skip further processing
            return

        # To pandas dataframe
        self.rolling_window = pd.DataFrame(prices)

        # Remove pre-market and after-hours data
        self.rolling_window = self.__strip_market_hours(self.rolling_window)

        # Print the rolling window to validate we get fresh data
        print(self.rolling_window)


    async def shift(self) -> bool:

        # Request latest bar from the API
        response = self.connector.request_latest_bar(self.ticker)

        # If no data available from API
        if len(response['data']) == 0:

            print(f'{self.ticker}: minutely bar is missing')

            # Return falsy bool to avoid
            # further calls in the runner
            return False

        # Parse out necessary values
        # from api response and cast to dataframe
        bar = self.__parse(response)

        # Drop tail minute from the window
        self.rolling_window = self.rolling_window.iloc[1 : ]

        # Append latest bar to the window and reset indices to avoid confusion
        self.rolling_window = self.rolling_window.append(bar, ignore_index=True)

        # Copy rolling window to another variable to calculate over
        self.calculation_window = self.rolling_window.copy()

        # Return truthy bool to proceed
        return True


    async def calculate(self) -> None:

        # Inject rolling dataframe and parameters into strategy
        self.strategy.consume(self.ticker, self.calculation_window, self.slice)

        # Calculate rolling values
        self.strategy.calculate()

        # Mark signals into the window
        self.strategy.mark_signals()

        # Clean NaN values from the window
        self.strategy.clean()


    async def dispatch(self) -> None:

        # Parse out calculated action and timestamps
        action = self.calculation_window.iloc[-1]['action']

        # Print the signal
        print(self.ticker, action)

        # If we got a signal and allow to dispatch it
        if action == 1.0 and self.dispatching_allowed:

            # Construct message
            message = f'BUY {self.ticker}'

            print(f'Dispatching. {message}')

            # Dispatch text message
            self.signal_client.send(text=message)

            # Flip a switch that limits signal throughput
            self.dispatching_allowed = False


    def __get_start_end(self) -> tuple[str, str]:

        now = datetime.now()
        end = now
        start = end - timedelta(days=1)

        backward_deltas = { 6: 2, 5: 1 }

        wd = start.weekday()

        # If yesterday falls on Sunday, Saturday
        if wd in backward_deltas.keys():

            # Trace back to Friday
            start = start - timedelta(days=backward_deltas[wd])

        # Start at midnight
        f = '%Y-%m-%d-00:00'

        return (start.strftime(f), end.strftime(f))


    def __strip_market_hours(self, dataframe: pd.DataFrame) -> pd.DataFrame:

        # Intermediary column that holds time of logged OHLCV
        dataframe['time'] = dataframe['datetime'].dt.strftime('%H:%M:%S')

        # Filter out only those rows that fall into valid market hours
        market_hours_only = dataframe[
            ('09:30:00' <= dataframe['time']) & (dataframe['time'] <= '16:00:00')
        ]

        # Drop intermediary column
        market_hours_only = market_hours_only.drop(columns=['time'])

        return market_hours_only


    def __parse(self, api_response: dict) -> pd.DataFrame:

        # Extract relevant data from the incoming data structure
        relevant_values = api_response['data'][0]

        # Construct a dictionary with the values
        latest_bar = {
            'datetime': self.__parse_dt(relevant_values['date']),
            'open': relevant_values['open'],
            'high': relevant_values['high'],
            'low': relevant_values['low'],
            'close': relevant_values['close'],
            'volume': int(relevant_values['volume'])
        }

        return pd.DataFrame([latest_bar])


    def __parse_dt(self, dt_string: str) -> datetime:

        # Construct datetime object from incoming datetime string
        dt = datetime.fromisoformat(dt_string)

        # Convert to Eastern Time
        dt = dt.astimezone(timezone('US/Eastern'))

        # To string and back, such that we save it
        # as mutated datetime object without any timezone
        dt = datetime.strptime(dt.strftime(self.dt_format), self.dt_format)

        return dt
