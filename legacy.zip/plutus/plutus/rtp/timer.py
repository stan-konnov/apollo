from datetime import datetime


class Timer:


    def __init__(self) -> None:

        # Declare previous timestamp
        self.prev_dt = datetime.now()


    def check_loop(self) -> bool:

        # Declare next timestamp
        next_dt = datetime.now()

        # Check if next point in time crossed the one-minute threshold
        if next_dt.minute != self.prev_dt.minute:

            print('Loop restarted')

            # Reset previous point to next point
            self.prev_dt = next_dt

            # Return truthy bool and datetime
            return True

        else:

            self.prev_dt = next_dt

            return False