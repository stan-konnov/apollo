## ML Training

1. update or add a new .json file in plutus/plutus/config
1. commit and merge to develop

The above steps should kick off a training job, and the following should be
produced:

1. results txt file in AWS Dev sf-dev-stocks-ml bucket under
strategy_name/backtesting-results.txt
1. model created with the same name as the .json config file (minus the .json
extension)

A (possibly long-lived) endpoint can be manually created from the trained model.
A more automated infra-as-code solution will be developed at a later time.

### ML Training strategy config json file

The strategy config file in plutus/plutus/config should look like this (note
that this is constantly evolving and this documentation may lag behind):

```
{
  "data_source": "uds",
  "indicators": ["dm", "pc", "sr", "rsi"],
  "with_indicators": true,
  "tickers": {
    "AAPL": {
      "markers": [],
      "time_periods": [
        {
          "start_date": "2022-05-01-00:00",
          "end_date": "2022-08-01-00:00"
        }
      ]
    }
  },
  "backtesting_config": {
    "window_size": 180,
    "stop_loss": [0.005, 0.01],
    "take_profit": [0.01, 0.02],
    "signal_threshold": [0.5, 0.7]
  },
  "backtesting": {
    "AAPL": {
      "time_periods": [
        {
          "start_date": "2023-05-02-00:00",
          "end_date": "2023-05-20-00:00"
        },
        {
          "start_date": "2021-11-01-00:00",
          "end_date": "2022-11-20-00:00"
        }

      ]
    },
    "NVDA": {
      "time_periods": [
        {
          "start_date": "2023-05-02-00:00",
          "end_date": "2023-05-05-00:00"
        }
      ]
    }
  }
}
```

It's possible that some parts of the example file above are no longer needed,
so this should be cleaned up, and we should elaborate on what each section is
for when we get around to it.

## Poetry

### 1. Install poetry:

<br />

```
brew install poetry
```

<br />

### 2. Install dependencies and create virtual environment:

<br />

```
poetry install
```

<br />

### 3. Add inputs:

<br />

```
cd plutus && mkdir inputs
```

<br />

Grab an input file and place it under aforementioned directory

<br />

### 4. Activate virtual environment:

<br />

```
(from plutus root) source ./venv/bin/activate
```

<br />

### 5. Run notebook:

<br />

```
jupyter notebook (you can alternatively use vsc extension)
```
